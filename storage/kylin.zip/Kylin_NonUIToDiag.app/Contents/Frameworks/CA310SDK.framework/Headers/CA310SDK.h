//
//  CA310SDK.h
//
//  Copyright (c) 2002-2013 KONICA MINOLTA, INC. 
//

#ifndef __CA310SDK_h__
#define __CA310SDK_h__

#ifndef HANDLE
#define HANDLE	void*
#endif
#ifndef LONG
#define	LONG	SInt32
#endif
#ifndef HRESULT
#define	HRESULT	LONG
#endif
#ifndef FLOAT
#define	FLOAT	double
#endif
#ifndef BSTR
#define BSTR	std::string
#endif
#ifndef CComBSTR
#define CComBSTR	std::string
#endif

#include <map>
#include <string>


// ErrorMSG
NSString* SDK_GetLocalizedErrorMsgFromErrorCode(HRESULT ErrorCode);


class COutputProbes;
class CProbe;
class CCommPort; 
class CProbeAliasID;  
class CCaAliasID;  

struct BSTRless : std::binary_function<CComBSTR, CComBSTR, bool>
{
	bool operator()(const CComBSTR& _X, const CComBSTR& _Y) const {
#if 0	
		return(wcscmp(_X.m_str, _Y.m_str) > 0);
#else		
		return(strcmp(_X.c_str(), _Y.c_str()) > 0);
#endif		
	}
};

struct SMemoryStatus
{
	LONG lProbeSNOC;
	LONG lProbeSNOR;
	LONG lCalMode;
	FLOAT frclrx;
	FLOAT frclry;
	FLOAT frclrLv;

	SMemoryStatus(){		
		lProbeSNOC = -1;
		lProbeSNOR = -1;
		lCalMode = -1;
		frclrx = -1.;
		frclry = -1.;
		frclrLv = -1.;
	}

};


/////////////////////////////////////////////////////////////////////////////
// CMemory
class CMemory
{
public:
	CMemory();
	~CMemory();
public:
	void ResetCalData();

	HRESULT CopyFromBufferToMemory(LONG lNumber, std::string *pstrBuffer);
	HRESULT CopyFromBufferToFile(LONG lNumber, std::string *pstrBuffer, CComBSTR strFileName);
	HRESULT CopyFromMemoryToBuffer(LONG lNumber, std::string *pstrBuffer);
	HRESULT CopyFromFileToBuffer(LONG lNumber, CComBSTR strFileName,  std::string *pstrBuffer);
	HRESULT GetMemoryStatusOfCurrentCH();

	void SetapSMSCurrent(LONG lProbeNumber, SMemoryStatus*  pSMemoryStatus);
	HRESULT UpdateCalData(BOOL bCal);
	void SetCOutputProbes(COutputProbes* pCOutputProbes);
	void SetDisplayProbeID(BSTR strID);
	void SetMemory(LONG lCH, std::string strID);
	void SetArrayOfCProbe(LONG lNumber, CProbe* pCProbe);
	HRESULT GetMemoryStatus();
	HRESULT CopyFromFile(LONG lNumber, BSTR strFileName);
	HRESULT CopyToFile(LONG lNumber, BSTR strFileName);
	HRESULT CheckCalData(LONG lNumber, BSTR strFileName, LONG* plResult);
	HRESULT GetMemoryStatus(LONG lNumber, LONG* lCProbeSNO, LONG* lRProbeSNO, LONG* lCalMode);
	HRESULT SetChannelID(BSTR strID);
	HRESULT GetReferenceColor(BSTR strID, FLOAT* frclrx, FLOAT* frclry, FLOAT* frclrLv);
	HRESULT get_ChannelID(BSTR *pVal);
	HRESULT put_ChannelID(BSTR newVal);
	HRESULT get_ChannelNO(LONG *pVal);
	HRESULT put_ChannelNO(LONG newVal);

	CCommPort *m_pclsCommPort;

private:
	LONG m_lCH;
	CComBSTR m_strID;

	CProbe* m_apCProbe[5];
	COutputProbes* m_pCOutputProbes;

	CComBSTR m_strDisplayProbeID;
	std::string m_astrID[100];
	SMemoryStatus m_aSMemoryStatus[5][100];
	SMemoryStatus* m_apSMSCurrent[5];

	LONG m_lCalModeOfData;
};

/////////////////////////////////////////////////////////////////////////////
// CProbe
class CProbe
{
public:
	CProbe();
	~CProbe();
public:
	HRESULT GetSpectrum(LONG Frequency,FLOAT *pSpectrumValue);
	void SetOutputProbe(BOOL bFalg);
	void InitData();

	void SetClone(CProbe *pCProbe);
	void SetClone(
		BOOL *pbOutputProbe,
		BOOL *pbClone,

		FLOAT *pfR,
		FLOAT *pfG,
		FLOAT *pfB,

		SMemoryStatus **ppSMSCurrent,
		CCommPort **ppclsCommPort,
		CProbeAliasID **ppCProbeAlias,

		LONG *plLUnit,
		FLOAT *pfsx,
		FLOAT *pfsy,
		FLOAT *pfFlckrFMA,
		BSTR *pbstrID,
		// LONG *plRCode,
		LONG *plRDataCode,
		LONG *plRADataCode,
		LONG *plRFlckrFMACode,
		LONG *plRFlckrJEITACode,
		FLOAT *pfduv,
		FLOAT *pfvs,
		FLOAT *pfus,
		FLOAT *pfLs,
		LONG *plT,
		FLOAT *pfvd,
		FLOAT *pfud,
		FLOAT *pfLv,
		BSTR *pbstrTime,
		BSTR *pbstrSTime,
		BSTR *pbstrSerialNO,
		LONG *plNumber,
		FLOAT *pfFlckrJEITA,
		double *pdZ,
		double *pdY,
		double *pdX,

		FLOAT *pfZW,
		FLOAT *pfYW,
		FLOAT *pfXW,

		FLOAT *pfdEUser,
		FLOAT *pfvsUser,
		FLOAT *pfusUser,
		FLOAT *pfLsUser,

		FLOAT *pfLvfL,
		FLOAT *pfxir,

		BSTR *pbstrTypeName,
		LONG *plTypeNO
						  );

	HRESULT get_RD(LONG *pVal);
	HRESULT get_RAD(LONG *pVal);
	HRESULT get_RFMA(LONG *pVal);
	HRESULT get_RJEITA(LONG *pVal);

	HRESULT get_B(FLOAT *pVal);
	HRESULT get_G(FLOAT *pVal);
	HRESULT get_R(FLOAT *pVal);

	HRESULT get_LvfL(FLOAT *pVal);
	HRESULT get_LsUser(FLOAT *pVal);
	HRESULT get_vsUser(FLOAT *pVal);
	HRESULT get_usUser(FLOAT *pVal);
	void UpdateData();
	void SetLUnit(LONG lLUnit);
	void SetpSMSCurrent(SMemoryStatus*  pSMemoryStatus);
	void GetDefaultID(BSTR* strID);
	void SetID(BSTR strID);
	HRESULT get_duv(FLOAT *pVal);
	HRESULT get_sy(FLOAT *pVal);
	HRESULT get_sx(FLOAT *pVal);
	int CalcFlckr(int *piData);
	int bit_reverse(double p0, int r0);
	HRESULT get_FlckrFMA(FLOAT *pVal);

	HRESULT get_dEUser(FLOAT *pVal);
	HRESULT get_T(LONG *pVal);
	HRESULT get_vd(FLOAT *pVal);
	HRESULT get_ud(FLOAT *pVal);
	HRESULT get_Lv(FLOAT *pVal);
	HRESULT get_SerialNO(BSTR *pVal);
	HRESULT get_ID(BSTR *pVal);
	HRESULT put_ID(BSTR newVal);
	HRESULT get_Number(LONG *pVal);
	HRESULT get_FlckrJEITA(FLOAT *pVal);
	HRESULT get_Z(FLOAT *pVal);
	HRESULT get_Y(FLOAT *pVal);
	HRESULT get_X(FLOAT *pVal);

	HRESULT GetSerialNO();
	void SetNumber(LONG newVal);

	void SetFlckrFMAData(FLOAT fFlckrFMA);
	int SetAData(FLOAT fR, FLOAT fG, FLOAT fB);
	int SetData(double dX, double dY, double dZ);

	void ResetFlckrJEITAData();
	void ResetFlckrFMAData();
	void ResetAData();
	void ResetData();
	void SetAll0Data();

	void SetFlckrJEITAStatus(LONG);
	void SetFlckrFMAStatus(LONG);
	void SetAStatus(LONG);
	void SetStatus(LONG);

	CCommPort *m_pclsCommPort;
	CProbeAliasID* m_pCProbeAlias;

private:

	BOOL m_bOutputProbe;
	BOOL m_bClone;

	FLOAT m_fR;
	FLOAT m_fG;
	FLOAT m_fB;

	FLOAT m_fdEUser;
	FLOAT m_fvsUser;
	FLOAT m_fusUser;
	FLOAT m_fLsUser;

	FLOAT m_fLvfL;
	FLOAT m_fZW;
	FLOAT m_fYW;
	FLOAT m_fXW;
	LONG m_lLUnit;
	FLOAT m_fsx;
	FLOAT m_fsy;
	FLOAT m_fFlckrFMA;
	FLOAT m_fduv;
	FLOAT m_fvs;
	FLOAT m_fus;
	FLOAT m_fLs;
	LONG m_lT;
	FLOAT m_fvd;
	FLOAT m_fud;
	FLOAT m_fLv;
	FLOAT m_fFlckrJEITA;
	double m_dZ;
	double m_dY;
	double m_dX;
	CComBSTR m_bstrTime;
	CComBSTR m_bstrSTime;

	// LONG m_lRCode;
	LONG m_lRDataCode;
	LONG m_lRADataCode;
	LONG m_lRFMACode;
	LONG m_lRJEITACode;

	CComBSTR m_bstrSerialNO;
	LONG m_lNumber;
	CComBSTR m_bstrID;
	SMemoryStatus* m_pSMSCurrent;

	FLOAT m_xir[256];

public:
	HRESULT GetTypeNameAndNO(void);
	HRESULT get_TypeNO(LONG *pVal);
	HRESULT get_TypeName(BSTR* pVal);
	
private:
	CComBSTR m_bstrTypeName;
	LONG m_lTypeNO;

};

/////////////////////////////////////////////////////////////////////////////
// CProbes
class CProbes
{
public:
	CProbes();
	~CProbes();
public:

	HRESULT SetProbeID(LONG lNumber, BSTR strID);
	HRESULT get_ItemOfNumber(LONG lNumber, CProbe* *pVal);
	HRESULT Add(CProbe* pVal);
	HRESULT get_Count(LONG *pVal);
	HRESULT get_Item(BSTR bstrVal, CProbe* *pVal);
	HRESULT get_Item(LONG vvIndex, CProbe* *pVal);

	CProbeAliasID* m_pCProbeAlias;

private:
	std::map<CComBSTR, CProbe*, BSTRless> m_mapIProbe;
};

/////////////////////////////////////////////////////////////////////////////
// COutputProbes
class COutputProbes
{
public:
	COutputProbes();
	~COutputProbes();
public:

	void SetClone();
	HRESULT AddProbe(CProbe* pCProbe);
	void SetArrayOfCProbe(LONG lNumber, CProbe *pCProbe);
	HRESULT SetOutputprobesToCA();
	void GetConnectString(char* strConnectString);
	BOOL CheckMember(LONG lNumber);
	HRESULT SetOutputProbes(BSTR vstrConnecString);
	HRESULT RemoveAll();
	HRESULT Clone(COutputProbes* *pVal);
	HRESULT AddAll();
	HRESULT get_ItemOfNumber(LONG lNumber, CProbe* *pVal);
	HRESULT Add(BSTR strID);
	HRESULT get_Count(LONG *pVal);
	HRESULT get_Item(BSTR bstrVal, CProbe* *pVal);
	HRESULT get_Item(LONG vvIndex, CProbe* *pVal);

	CProbeAliasID* m_pCProbeAlias;
	CCommPort *m_pclsCommPort;
private:
	std::map<CComBSTR, CProbe*, BSTRless> m_mapIProbe;

	CProbe* m_apCProbe[5];
	BOOL m_bMember[5];
	BOOL m_bClone;
};

typedef struct{
	int dspmode;
	int syncmode;
	std::string fsync;
	int memch;
	std::string memid;
	std::string rng1;
	std::string rng2;
	int calmode;
	int lunit;
	int fsmode;
	int dspdigit;
	int calstd;
	std::string prb;
	std::string dspprb;
	std::string outprb;
	int calstate;
	int wcal;
	int rcal;
	int gcal;
	int bcal;
} SCaStatus;

/////////////////////////////////////////////////////////////////////////////
// CCa
class CCa
{
public:
	CCa();
	~CCa();
public:
	HRESULT Command(BSTR CommandVal, BSTR* ResponseVal);

	HRESULT GetFMAAnalogRange(FLOAT *pfRange);
	HRESULT GetAnalogRange(FLOAT *pfRange1, FLOAT *pfRange2);
	HRESULT SetFMAAnalogRange(FLOAT Range);
	HRESULT ReceiveMSR(LONG newVal);
	HRESULT CheckFMA(void);
	HRESULT SendMSR(LONG newVal);
	HRESULT put_RemoteMode(LONG newVal);
	HRESULT SetSingleProbe(void);
	HRESULT SetLvxyCalData(LONG lClr, FLOAT fx, FLOAT fy, FLOAT fLv);
	HRESULT SetAnalyzerCalData(LONG lClr);
	HRESULT SetDisplayProbe(LONG lDisplayProbe);
	HRESULT ResetLvxyCalMode();
	HRESULT SetLvxyCalMode();
	HRESULT ResetAnalyzerCalMode();
	HRESULT put_CalStandard(LONG newVal);
	HRESULT get_CalStandard(LONG *pVal);
	HRESULT GetProbeNumber(LONG lIndex, LONG* plProbeNumber);
	HRESULT SetConfiguration(LONG vlNumber,BSTR vstrConnecString,LONG lPort,LONG lBaudRate);
	HRESULT SetPWROnStatus();
	HRESULT SetAnalogRange(FLOAT Range1, FLOAT Range2);
	HRESULT Enter();
	HRESULT SetAnalyzerCalMode();
	HRESULT Measure();
	HRESULT CalZero();
	HRESULT get_ID(BSTR *pVal);
	HRESULT put_ID(BSTR newVal);
	HRESULT get_PortID(BSTR *pVal);
	HRESULT get_Number(LONG *pVal);
	HRESULT get_CAVersion(BSTR *pVal);
	HRESULT get_CAType(BSTR *pVal);
	HRESULT put_BrightnessUnit(LONG newVal);
	HRESULT get_BrightnessUnit(LONG *pVal);
	HRESULT put_AveragingMode(LONG newVal);
	HRESULT get_AveragingMode(LONG *pVal);
	HRESULT put_DisplayDigits(LONG newVal);
	HRESULT get_DisplayDigits(LONG *pVal);
	HRESULT put_DisplayMode(LONG newVal);
	HRESULT get_DisplayMode(LONG *pVal);
	HRESULT put_SyncMode(FLOAT newVal);
	HRESULT get_SyncMode(FLOAT *pVal);
	HRESULT get_SingleProbe(CProbe* *pVal);
	HRESULT put_DisplayProbe(BSTR newVal);
	HRESULT get_DisplayProbe(BSTR *pVal);
	HRESULT get_Memory(CMemory* *pVal);
	HRESULT get_OutputProbes(COutputProbes* *pVal);
	HRESULT get_Probes(CProbes* *pVal);

	CCommPort *m_pclsCommPort;
	CCaAliasID* m_pCCaAlias;
	CProbeAliasID* m_pCProbeAlias;

	int getUSB(void);
	void setUSB(int);

private:
	LONG LockRemote();
	void SetCaStatus(void);
	LONG GetCaStatus(void);
	
	SCaStatus m_sCaStatus;
	SCaStatus m_sPrptyCaStatus;
	CComBSTR m_bstrDisplayProbeID;

	HANDLE m_hMutex;
	CComBSTR m_bstrCaID;
	LONG m_lNumber;


	CProbes* m_pCProbes;
	COutputProbes* m_pCOutputProbes;
	CMemory* m_pCMemory;
	CProbe* m_apCProbe[5];
	SMemoryStatus* m_apSMSCurrent[5];

	int m_iucalstate;
	int m_iuwcal;
	int m_iurcal;
	int m_iugcal;
	int m_iubcal;

	int m_iCAType;
	double m_dLMax;
	double m_dLMin;

	int m_OldRom;
	int m_DebugON;
	int m_DisplayProbeBuffer;
	int m_RangeInfo[5];

	int m_iUSB;
public:
	static bool m_bIsCA310;
	static bool m_bIsUnitfL;
};

/////////////////////////////////////////////////////////////////////////////
// CCas
class CCas
{
public:
	CCas();
	~CCas();
public:

	void SetapCCa(LONG lNumber, CCa* pCCa);
	HRESULT SetCaID(LONG lNumber, BSTR strID);
	HRESULT get_ItemOfNumber(LONG lNumber, CCa* *pVal);
	HRESULT ReceiveMsr();
	HRESULT SendMsr();
	HRESULT Add(CCa*);
	HRESULT get_Count(LONG *pVal);
	HRESULT get_Item(BSTR bstrVal, CCa* *pVal);
	HRESULT get_Item(LONG vvIndex, CCa* *pVal);

	CCaAliasID* m_pCCaAlias;

	int getCount();

private:
	HRESULT m_aHRESULT[5];
	std::map<CComBSTR, CCa*, BSTRless> m_mapICa;
	CCa* m_apCCa[5];

	bool m_bIsSent;
};

/////////////////////////////////////////////////////////////////////////////
// CCa200
class CCa200
{
public:
	CCa200();
	~CCa200();
public:

	HRESULT AutoConnect();
	HRESULT SetConfiguration(LONG vlNumber, BSTR vstrConnecString, LONG lPort);	
	HRESULT get_Cas(CCas* *pVal);
	HRESULT get_SingleCa(CCa* *pVal);

	CCaAliasID* m_pCCaAlias;

private:
	CCa* m_apCCa[5];
	CCas* m_pCCas;

	int m_iUSB;
	
};

#endif // __CA310SDK_h__
