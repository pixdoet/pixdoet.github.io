----------------------------------------public function------------------------------------------
function getDylibVersion()
  local dylibKeys = {"utils", "serial", "ip", "sfc", "cba", "scb", "message", "ca310", "ezlink"}
  local versionInfo = "";
  for key, value in pairs(dylibKeys) do
    local bStatus, tbDylib = pcall(require, value);
    if bStatus and tbDylib then
      local version = tbDylib.getVersion();
      versionInfo = versionInfo .. value .. ": " .. version .. "\n";
    end
  end
  return versionInfo;
end

function CRCCalculate(crc, byteSource)
  checkSum = (crc ~ (byteSource << 8))
  for i = 0, 7 do
    if (checkSum&0x8000 > 0) then
      checkSum  = ((checkSum << 1)~ 0x1021) 
    else
      checkSum = (checkSum <<1)  
    end
  end
  checkSum = (checkSum & 0xFFFF)
  return checkSum
end

------------------------------------------------
function file_exists(path)
  local file = io.open(path, "rb")
  if file then 
    file:close()
    return true
  end
  return false
end

------------------------------------------------
function getPlistInfo(path)
  local file = io.input(path)
  local str = io.read("*all")
  local DBClValue,DTClValue,DBClResult,DTClResult
  local count = 0
  for w in string.gmatch(str,"(<key>upperlimit</key>)") do
    count = count+1
  end
  local a,b,c,d = 0
  for i=1,count-1 do
    a,b,result = string.find(str,"<key>result</key>%s*<string>(%a*)</string>",b)
    c,d,value = string.find(str,"<key>value</key>%s*<string>(%d*%.-%d*)</string>",d)
    if i==2 then
      DBClValue = value
      DBClResult = result
    end
    if i==3 then
      DTClValue = value
      DTClResult = result
    end
  end 
  return DBClValue,DTClValue,DBClResult,DTClResult
end


------------------------------------------------
function compareAandB(strValue,LowerLimit,upperLimit,containEqual)
  if strValue == nil or tonumber(strValue) == nil then
    return false
  end
  local BValue = false
  if (upperLimit == "NA" or upperLimit == "N/A") and (LowerLimit == "NA" or LowerLimit == "N/A") then
    BValue =  true
  elseif LowerLimit == "NA" or LowerLimit == "N/A" then
    local strValueNum, upperLimitNum = tonumber(strValue), tonumber(upperLimit)
    if containEqual == "true" or containEqual == "True" or containEqual == "TRUE" or containEqual == true then
      BValue = strValueNum <= upperLimitNum and true or false
    else
      BValue = strValueNum < upperLimitNum and true or false
    end
  elseif upperLimit == "NA" or upperLimit == "N/A" then
    local strValueNum, LowerLimitNum = tonumber(strValue), tonumber(LowerLimit)
    if containEqual == "true" or containEqual == "True" or containEqual == "TRUE" or containEqual == true then
      BValue = strValueNum >= LowerLimitNum and true or false
    else
      BValue = strValueNum > LowerLimitNum and true or false
    end 
  else
    local strValueNum, LowerLimitNum, upperLimitNum = tonumber(strValue), tonumber(LowerLimit), tonumber(upperLimit)
    if containEqual == "true" or containEqual == "True" or containEqual == "TRUE" or containEqual == true then
      BValue = strValueNum <= upperLimitNum and strValueNum >= LowerLimitNum and true or false
    else
      BValue = strValueNum < upperLimitNum and strValueNum > LowerLimitNum and true or false
    end
  end
  return BValue
end

------------------------------------------------
function parseStrWithSpec(self)
  local rtSend,rtRecv = nil, nil
  for i=1, #self.cmdSet do
    rtSend,rtRecv = doDiagsCmd(self.cmdSet[i])
  end
  if self.specSet.Captures ~= nil then
    _,_,rtRecv = string.find(rtRecv or " ",self.specSet.Captures)
  end
  local bResult = string.match(rtRecv or " ",self.specSet.spec) and true or false
  ResultTable.resultCode = bResult
  --ResultTable.resultString = string.match(rtRecv or " ",self.specSet.spec) or "Fail"
end 
------------------------------------------------

function parseStrWithLimit(self)
  local rtSend,rtRecv = nil, nil 
  if self.device == "Fixture" then
    rtSend,rtRecv = doScorpiusCmd(self.cmdSet[1])
  else
    rtSend,rtRecv = doDiagsCmd(self.cmdSet[1])
  end  
  local _,_,logResult = string.find(rtRecv or "",self.limitSet.Captures)
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end

------------------------------------------------
local localCSVFile = Directory.homePublic .. "/Parametric.csv"
-- function uploadDataToPDCA(self)
--   print("enter uploadDataToPDCA")
--   local existFile = file_exists(localCSVFile)
--   print(existFile)
--   if not existFile then
--     local snFile1 = assert(io.open(localCSVFile,'w'))
--     snFile1:write("testItemName" .. ",")
--     snFile1:write("Lower Limit" .. ",")
--     snFile1:write("Value" .. ",")
--     snFile1:write("Upper Limit" .. ",")
--     snFile1:write("Units" .. ",")
--     snFile1:write("Priority" .. ",")
--     snFile1:write("\n")
--     snFile1:close()
--   end
--   local snFile1 = assert(io.open(localCSVFile,'a')) 
--   for key1,val1 in pairs(g_PDCAParametric) do
--     local low = val1.low
--     local value = val1.value
--     local high = val1.high
--     local result = val1.result
--     local priority = val1.priority
--     local testName = val1.testName  
--     local SubTestItem = val1.SubTestItem
--     local SubSubTestItem = val1.SubSubTestItem
--     local failMsg = val1.failMsg  
--     local TestUnit = val1.TestUnit

--     testName = string.gsub(testName,"%s+%b[]","")
--     local valueType = tonumber(value)

--     local testNameCSV = nil
--     if type(valueType) == "number" and (low and high) and tostring(low):len()>0 and tostring(high):len()>0 then
--       if SubTestItem ~= nil and SubSubTestItem == nil then
--         print("SubTestItem",SubTestItem)
--         testNameCSV = testName .. " " .. SubTestItem
--       elseif SubTestItem ~= nil and SubSubTestItem ~= nil then
--         testNameCSV = testName .. " " .. SubTestItem .. " " .. SubSubTestItem
--       else
--         testNameCSV = testName
--       end  

--       snFile1:write(testNameCSV .. ",") 
--       snFile1:write(low .. ",")
--       snFile1:write(value .. ",")
--       snFile1:write(high .. ",")
--       snFile1:write(TestUnit .. ",")
--       snFile1:write(priority .. ",")
--       snFile1:write("\n")      
--     end

--     if key1==nil and val1==nil then
--       break
--     end
--   end
--   snFile1:close()
--   local aString = g_finalResult and "PASS" or "FAIL"
--   FilePath = app.getLogFile({resultString=aString , sn = sn})
--   FilePathCSV = FilePath:gsub(".txt",".csv")

--   os.execute("mv " .. localCSVFile .. " " .. "\"" .. FilePathCSV .. "\"")
--   local localZipPath = Directory.homePublic .. "/Parametric.zip"
-- --  os.execute("zip -j " .. Directory.homePublic .. "/Parametric.zip " .. "\"" .. FilePathCSV .. "\"" .. " " .. "\"" .. FilePath .. "\"")
--   local zipCommand = "zip -j " .. Directory.homePublic .. "/Parametric.zip"
--   zipCommand = zipCommand .. " \"" .. FilePathCSV .. "\""
--   zipCommand = zipCommand .. " \"" .. FilePath .. "\""
--   for i in pairs(ComTable) do
--     if string.match(i, "LPP_filepath") then
--       zipCommand = zipCommand .. " \"" .. ComTable[i] .. "\""
--     end  
--   end  
--   os.execute(zipCommand)
--   zipPath = FilePath:gsub(".txt",".zip")
--   os.execute("mv " .. localZipPath .. " " .. "\"" .. zipPath .. "\"")

--   return zipPath  
-- end
function uploadDataToPDCA(self)
  print("enter uploadDataToPDCA")
  local existFile = file_exists(localCSVFile)
  print(existFile)
  if not existFile then
    local snFile1 = assert(io.open(localCSVFile,'w'))
    snFile1:write("testItemName" .. ",")
    snFile1:write("Lower Limit" .. ",")
    snFile1:write("Value" .. ",")
    snFile1:write("Upper Limit" .. ",")
    snFile1:write("Units" .. ",")
    snFile1:write("Priority" .. ",")
    snFile1:write("\n")
    snFile1:close()
  end
  local snFile1 = assert(io.open(localCSVFile,'a')) 
  for key1,val1 in pairs(g_PDCAParametric) do
    local low = val1.low
    local value = val1.value
    local high = val1.high
    local result = val1.result
    local priority = val1.priority
    local testName = val1.testName  
    local SubTestItem = val1.SubTestItem
    local SubSubTestItem = val1.SubSubTestItem
    local failMsg = val1.failMsg  
    local TestUnit = val1.TestUnit

    testName = string.gsub(testName,"%s+%b[]","")
    local valueType = tonumber(value)

    local testNameCSV = nil
    if type(valueType) == "number" and (low and high) and tostring(low):len()>0 and tostring(high):len()>0 then
      if SubTestItem ~= nil and SubSubTestItem == nil then
        print("SubTestItem",SubTestItem)
        testNameCSV = testName .. " " .. SubTestItem
      elseif SubTestItem ~= nil and SubSubTestItem ~= nil then
        testNameCSV = testName .. " " .. SubTestItem .. " " .. SubSubTestItem
      else
        testNameCSV = testName
      end  

      snFile1:write(testNameCSV .. ",") 
      snFile1:write(low .. ",")
      snFile1:write(value .. ",")
      snFile1:write(high .. ",")
      snFile1:write(TestUnit .. ",")
      snFile1:write(priority .. ",")
      snFile1:write("\n")      
    end

    if key1==nil and val1==nil then
      break
    end
  end
  snFile1:close()
  local aString = g_finalResult and "PASS" or "FAIL"
  FilePath = app.getLogFile({resultString=aString , sn = sn})
  FilePathCSV = FilePath:gsub(".txt",".csv")

  os.execute("mv " .. localCSVFile .. " " .. "\"" .. FilePathCSV .. "\"")


  local log_analyse_tool_path = Directory.tools .."/Kylin_log_analyse_1"
  os.execute(log_analyse_tool_path .. " " ..  FilePath) --Created file at path app.getLogFile({resultString="Henry" , sn = sn}):gsub(".txt","") .. "_records.csv"
  local created_recordPath = app.getLogFile({resultString=aString , sn = sn}):gsub(".txt","") .. "_records.csv"
  local failLogPath = createFailureLog()

  local localZipPath = Directory.homePublic .. "/Parametric.zip"

  local zipCommand = "zip -j " .. Directory.homePublic .. "/Parametric.zip"
  zipCommand = zipCommand .. " \"" .. FilePathCSV .. "\""
  zipCommand = zipCommand .. " \"" .. FilePath .. "\""
  zipCommand = zipCommand .. " \"" .. created_recordPath .. "\""
  zipCommand = zipCommand .. " \"" .. failLogPath .. "\""
  -- g_gsmPath = app.getLogFile({resultString=aString , sn = sn}):gsub(".txt","") .. "_GSMRosalineCoex.csv"
  -- print("------tempD:ee", g_gsmPath)
  -- zipCommand = zipCommand .. " \"" .. g_gsmPath .. "\""
  zipCommand = zipCommand .. " \"" .. Directory.home .. "/DCsig_at_F1.txt" .. "\""
  zipCommand = zipCommand .. " \"" .. Directory.home .. "/DCsig_at_F3.txt" .. "\""
  zipCommand = zipCommand .. " \"" .. Directory.home .. "/DCsig_at_500Hz.txt" .. "\""
  zipCommand = zipCommand .. " \"" .. Directory.home .. "/Display_touch_noise_data.txt" .. "\""

    for i in pairs(ComTable) do
        if string.match(i, "_rawADC_path") then
            zipCommand = zipCommand .. " \"" .. ComTable[i] .. "\""
        end
    end  

  os.execute(zipCommand)
  zipPath = FilePath:gsub(".txt",".zip")
  os.execute("mv " .. localZipPath .. " " .. "\"" .. zipPath .. "\"")

  ResultTable.resultCode = true

  return zipPath  
end

function resetOffset(number)
  if ComTable["offset"] == 1 then
    doScorpiusCmd("left 2\r")
  elseif ComTable["offset"] == 2 then
    doScorpiusCmd("down 2\r")
  elseif ComTable["offset"] == 3 then
    doScorpiusCmd("down 2\r")
    doScorpiusCmd("left 2\r")
  else
    print("No Offset")
  end
  print("reset Offset ok")
end

function createFailureLog()
    local snFile1 = assert(io.open(localCSVFile,'w')) 
    local path = app.getLogFile({sn = sn}):gsub(".txt","") .. "_failures.csv"
    local file = assert(io.open(path,'w'))
    file:write("TestName"..",")
    file:write("FailInfo"..",")
    file:write("Duration")
    file:write("\n")
    for i,v in pairs(g_PDCAParametric) do
        if v.result == false then
            local TestName = string.format("\"%d. %s\"", i, v.testName)
            local FailInfo = "\""..string.gsub(v.value,"\r"," "):gsub("\n"," ").."\""
            file:write(TestName..",")
            file:write(FailInfo..",")
            file:write(v.duration)
            file:write("\n")
        end
    end
    file:close()
    return path  
end


-------------------------------------------------------------------------------------------



