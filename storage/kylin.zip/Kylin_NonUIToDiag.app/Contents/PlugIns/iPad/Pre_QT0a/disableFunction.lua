--local function itemBurnTCID(self)
--  local KeyVersion = "0x01000000 "
--  local TempBuffer = ""
--  local DataNumbers, DataNumbersHx, Temps, TempsHx = {}, {}, {}, {}
--  local NFact ,Offset, QNFI, QNFD, QNF, QOffI, QOffD, QOff= {},{},{},{},{},{},{},{}
--  local i, NF = 0, 0
--  local rtSend,rtRecv = doDiagsCmd("dptx --auxread i2c 0x54 0x6d00 2 18\n")
--  TempBuffer = string.match(rtRecv,"Aux Data RX:(.+)OK\n")
--  -- For each row in the output data, extract data bytes and convert to an array of numbers
--  for RowString in TempBuffer:gmatch("0x%x+%:([^\n]+)") do
--    for DataByte in RowString:gmatch("%s+(0x%x+)") do
--      DataNumbers[i] = tonumber(DataByte)ß
--      DataNumbersHx[i] = DataByte
--      i = i + 1
--    end
--  end
--  -- Convert to words and Temperatures
--  for j = 0,8 do
--    TempsHx[j] = (DataNumbers[2*j] * 256) + DataNumbers[2*j+1]
--    Temps[j] = TempsHx[j]/128;
--  end
--  -- Set the default NFactor and Offset values
--  for j = 1,8 do
--    NFact[j] = 1.0029
--    Offset[j] = -0.7574
--  end
--  -- Calculate N-Factors
--  -- If problem with any of the values, then leave the defaults
--  -- Problems include: Temp > 100C, Any of Lower 3 bits of temperature word being 1, or NFact calculation being outside limits of [0.98444 - 1.0077]
--  if(Temps[0] < 100.0 and (DataNumbers[1] & 0x07) == 0) then
--    for j = 1,8 do
--      if(Temps[j] < 100.0 and (DataNumbers[2*j+1] & 0x7) == 0) then
--        NF = (Temps[j] + 273.15) / (Temps[0] + 273.15) * 1.008
--        if (NF < 1.0077 and NF > 0.98444) then
--          NFact[j] = NF;
--          Offset[j] = 0.0000
--        end
--      end
--    end
--  end
--  -- Convert NFact and Offset to Q12:20 fixed point format
--  for j = 1,8 do
--    QNFI[j] = math.floor(NFact[j])
--    QNFD[j] = math.floor((NFact[j]-QNFI[j])*1024*1024)
--    QNF[j] = (QNFI[j] << 20 ) + QNFD[j];
--    QOffI[j] = math.floor(Offset[j])
--    QOffD[j] = math.floor((Offset[j]-QOffI[j])*1024*1024)
--    QOff[j] = (QOffI[j] << 20 ) + QOffD[j];
--  end
--  local cmd = nil
--  cmd = KeyVersion .. string.format("0x%X",TempsHx[0])
--  for i=1, 8 do 
--    cmd = cmd .. string.format(" 0x%04X",TempsHx[i])
--  end 
--  for i=1, 8 do 
--    cmd = cmd .. string.format(" 0x%08X",QNF[i])
--  end 
--  for i=1, 8 do 
--    cmd = cmd .. string.format(" 0x%08X",QOff[i]&0xFFFFFFFFF)
--  end 
--  print(cmd)
--  cmd = "syscfg add TCID " .. cmd .. "\n"
--  rtSend,rtRecv = doDiagsCmd(cmd)
--  local bResult = string.match(rtRecv or " ",self.specSet.spec) and true or false
--  ResultTable.resultCode = bResult
--end

--table.insert(TestItems, {name="LCM_CFG", action=itemGetInfoFromLCMFullSN, subFrom=18, subTo=20})

--test item 61. Compare LCD SN between SFC and LCD module(kevin)
--local function itemCompareLCDTest(self)--sfc lcmsn compare with unit lcmsn(diag cmd:display --edid)
--  local rtSend,rtRecv = doDiagsCmd("display --on\n")
--  rtSend,rtRecv = doDiagsCmd("display --edid\n")
--  local _,_,unitrecvStr1= string.find(rtRecv or "","Serial Number   : (%w*)")
--  --compare them need ignore string.upper or string.lower
--  local UpperunitrecvStr1, UpperLcmsn = string.upper(unitrecvStr1 or ""), string.upper(lcmsn or "")
--  if string.len(UpperunitrecvStr1 or "")>0 and string.len(lcmsn or "")>0 then
--    bResult = UpperunitrecvStr1 == UpperLcmsn or string.match(UpperunitrecvStr1,UpperLcmsn) == UpperLcmsn and true or false
--  else
--    bResult = false
--  end
--  local logResult = bResult and unitrecvStr1 or "Fail" 
--  ResultTable.resultCode = bResult
--  ResultTable.resultString = logResult
--end
--table.insert(TestItems, {name="Compare LCD SN between SFC and LCD module", action=itemCompareLCDTest})

--test item "Display power smokey sequence"
--local function itemDisplayPowerSmokeyS(self)
--  local rtSendTmp,rtRecvTmp = doDiagsCmd("smokeyshell -r\n")
--  local rtSend = iPadSerial:send("smokey DisplayPower --run --clean\n") 
--  local log = string.format("send[%s]:%s", (rtSend==0 and "Success" or "Fail"), "smokey DisplayPower --run --clean" or "cmd empty")
--  table.insert(ResultLog,log)
--  local rtRecv = nil
--  if rtSend == 0 then
--    rtRecv = iPadSerial:recv("] :-) ", 4)
--    local logTmpTable = {}
--    --log = string.format("recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
--    local logTmp = string.format("recv[%s]:", (rtRecv and "Success" or "Fail"))
--    table.insert(logTmpTable,logTmp)
--    table.insert(logTmpTable,rtRecv or "no data\n")
--    local log = table.concat(logTmpTable,"")
--    table.insert(ResultLog,log)
--  end
--  if rtRecv == nil then
--    local bResult = false 
--    ResultTable.resultCode = bResult
--    ResultTable.resultString = "No Receive Data!"
--    return
--  end
--  _,_,rtRecv = string.find(rtRecv or " ","Sequence done%s+(.-)%s",-150)
--  local bResult = string.match(rtRecv or " ",self.specSet.spec) and true or false
--  ResultTable.resultCode = bResult
--end
--table.insert(TestItems, {name="Display power smokey sequence", action=itemDisplayPowerSmokeyS})
--TestItems[#TestItems].specSet = {spec = "Passed"}

--local function itemDisplayPowerData(self)
--  local  testNameTable,subTestNameTable,resultTable,valueTable,lowerlimitTable,upperlimitTable = {},{},{},{},{},{}
--  rtSend,rtRecv = doDiagsCmd("dfufile --read nandfs:\\AppleInternal\\Diags\\Logs\\Smokey\\DisplayPower\\PDCA.plist\n")
--  local bResult = true
--  if rtRecv == nil then
--    bResult = false 
--    ResultTable.resultCode = bResult
--    ResultTable.resultString = "dfufile --read nandfs:No Receive Data!"
--    return
--  end
--  --path = "/Users/11111/Desktop/Kylin-Development-6/CT1_Kylin/PDCA.plist"
--  path="/Users/gdlocal/PDCA.plist"
--  local isExistFile = file_exists(path)
--  if isExistFile then
--    local file = io.input(path)
--    local str = io.read("*all")   
--    local testNameRegular = "<key>testname</key>%s+<string>(.-)</string>"
--    local subTestNameRegular = ".-%s+<string>(.-)</string>"
--    local resultRegular = ".-result</key>%s+<string>(.-)</string>"
--    local valueRegular = ".-value</key>%s+<string>(.-)</string>"
--    local lowerlimitRegular = ".-lowerlimit</key>%s+<string>(.-)</string>"
--    local upperlimitRegular = ".-upperlimit</key>%s+<string>(.-)</string>"
--    local regular = testNameRegular .. subTestNameRegular .. resultRegular .. valueRegular .. lowerlimitRegular .. upperlimitRegular
--    for testName,subTestName,result,value,lowerlimit,upperlimit in string.gmatch(str,regular) do
--      table.insert(testNameTable,testName)
--      table.insert(subTestNameTable,subTestName)
--      table.insert(resultTable,result)
--      table.insert(valueTable,value)
--      table.insert(lowerlimitTable,lowerlimit)
--      table.insert(upperlimitTable,upperlimit)
--    end
--    for i=2, #testNameTable-1 do 
--      print("kevin test aaa")
--      print(valueTable[i])
--      Parametric={subName={low=lowerlimitTable[i], value=valueTable[i], high=upperlimitTable[i], result=resultTable[i], priority=0, testName=testNameTable[i],SubTestItem=subTestNameTable[i],SubSubTestItem="",failMsg="N/A",TestUnit="mV"}}
--      table.insert(PDCAInfo,Parametric)
--      print(subTestNameTable[i])
--    end  
--    ResultTable.resultCode = bResult
--  else
--    bResult = false 
--    ResultTable.resultCode = bResult
--    ResultTable.resultString = "No PDCA.plist file"
--  end
--end
--table.insert(TestItems, {name="DisplayPower Data", action=itemDisplayPowerData})


--test item 99. Check Moped Hash
--local function itemCMopedHash(self)
--  local rtSend,rtRecv = doDiagsCmd("hash --type Moped --append\n")
--  rtSend,rtRecv = doDiagsCmd("hash --type Moped --check\n")
--  local bResult = string.match(rtRecv or " ",self.set[1]) and true or false
--  if bResult == false then 
--    rtSend,rtRecv = doDiagsCmd("syscfg delete MdlC\n")
--    rtSend,rtRecv = doDiagsCmd("hash --type Moped --append\n")
--    rtSend,rtRecv = doDiagsCmd("hash --type Moped --check\n")
--  end

--  ResultTable.resultCode = bResult
--end
--table.insert(TestItems, {name="Check Moped Hash", action=itemCMopedHash, set = {"PASS"} }) 

--test item 101. Write Connectivity CB
--local function itemWriteStationCB(self)
--  local bResult, logResult = WriteStationCB(0x83,nil)
--  local rtSendReSet,rtRecvReSet = doScorpiusCmd("RESET\n")
--  ResultTable.resultCode = bResult
--  ResultTable.resultString = logResult
--end
--table.insert(TestItems, {name="Write Connectivity CB", action=itemWriteStationCB}) 

--3.NetWork CB: Check Fatal Error
local function NetWorkCBCFE(self)
  local bResult = nil
  local logResult = nil
  if sn == nil then
    bResult = false
    logResult = "Fail To Get SN!"
    ResultTable.resultCode = bResult
    ResultTable.resultString = logResult
    return
  end
  apiRely, uutHandle = ip.UUTStart()
  if ip.success(apiRely) then
    reply=ip.amIOkay(uutHandle,sn)
    successBool = ip.success(reply)
    print(successBool)
    if not successBool then
      DoneError = ip.reply_getError(apiRely)
      bResult = false
      logResult = DoneError
      cancelreply = ip.UUTCancel(uutHandle)
      ip.reply_destroy(cancelreply)
      ip.reply_destroy(reply)
      ip.UID_destroy(uutHandle)
      ResultTable.resultCode = bResult
      ResultTable.resultString = logResult
      return 
    end
  else
    DoneError = ip.reply_getError(apiRely)
    bResult = false
    logResult = DoneError 
    cancelreply = ip.UUTCancel(uutHandle)
    ip.reply_destroy(cancelreply)
    ip.reply_destroy(reply)
    ip.UID_destroy(uutHandle)
    ResultTable.resultCode = bResult
    ResultTable.resultString = logResult
    return 
  end

  bCheckPriorAllItemResult = finalResult
  print("bCheckPriorAllItemResult")
  print(bCheckPriorAllItemResult)
  iLength = 0
  if bCheckPriorAllItemResult then
    intCheckPriorCBPass,slengthPass = cba.GetCountCBsToClearOnPassSN(sn,iLength)
    if slengthPass ~= nil and slengthPass > 0 then
      intCheckPriorCBZZZZ,ipControlBitsArrayPass,slength = cba.ControlBitsToClearOnPassSN(sn,slengthPass)
      if intCheckPriorCBZZZZ then
        bResult = true
        logResult = "Pass"
        ResultTable.resultCode = bResult
        ResultTable.resultString = logResult
        return 
      end
    else
      bResult = true
      logResult = "Clear CBs On Pass is off or no station to clear"
      ResultTable.resultCode = bResult
      ResultTable.resultString = logResult
      return 
    end

  else
    intCheckPriorCBFail,slengthFail = cba.GetCountCBsToClearOnFailSN(sn,iLength)
    print(intCheckPriorCBFail)
    print(slengthFail)
    if slengthFail ~= nil and slengthFail >0 then
      intCheckPriorCBZZZZFail,ipControlBitsArrayFail,slength = cba.ControlBitsToClearOnFailSN(sn,slengthFail)
      if intCheckPriorCBZZZZFail then
        for i in pairs(ipControlBitsArrayFail) do
          print(ipControlBitsArrayFail[i])
          strStationCBAddress = string.format("0x%0.2X",ipControlBitsArrayFail[i])
          print("strStationCBAddress=")
          print(strStationCBAddress)
          local cmd = "cbwrite " .. selectedStationCB .. " fail\n"
          local rtSend = iPadSerial:send(cmd) 
          if not rtSend then
            strFailMSG = "Fail" .. strStationCBAddress
            bResult = false
            logResult = strFailMSG
            ResultTable.resultCode = bResult
            ResultTable.resultString = logResult
            return 
          end 
        end
        bResult = true
        logResult = "Pass"
        ResultTable.resultCode = bResult
        ResultTable.resultString = logResult
        return 
      end
    else
      bResult = true
      logResult = "CBs to Clear On fail is off or no station to clear"
      ResultTable.resultCode = bResult
      ResultTable.resultString = logResult
      return 
    end

  end

  intNeedToSetCB = cba.StationSetControlBitSN(sn)
  if intNeedToSetCB ~= true then
    bResult = false
    logResult = "Don't need to set CB"
    ResultTable.resultCode = bResult
    ResultTable.resultString = logResult
    return 
  end
end
table.insert(TestItems, {name="NetWork CB: Check Fatal Error", action=NetWorkCBCFE})

--4.NetWork CB: Check Previous Station CBs
local function NetWorkCBCPSC(self)
  local Ltable = {}
  local bResult = nil
  local logResult = nil
  myStationCB="0x7A"
  local rtSend,snRecvStr = doDiagsCmd("cbreadall\n")
  if snRecvStr == nil then
    bResult = false
    logResult = "Fail to Get All CB Status"
    ResultTable.resultCode = bResult
    ResultTable.resultString = logResult
    return
  end
  if sn == nil then
    bResult = false
    logResult = "Fail To Get SN!"
    ResultTable.resultCode = bResult
    ResultTable.resultString = logResult
    return
  end
  apiRely, uutHandle = ip.UUTStart()
  if ip.success(apiRely) then
    reply=ip.amIOkay(uutHandle,sn)
    if ip.success(reply) ~= true then
      local DoneError = ip.reply_getError(apiRely)
      bResult = false
      logResult = DoneError
      cancelreply = ip.UUTCancel(uutHandle)
      ip.reply_destroy(cancelreply)
      ip.reply_destroy(reply)
      ip.UID_destroy(uutHandle)
      ResultTable.resultCode = bResult
      ResultTable.resultString = logResult
      return
    end
  else
    local DoneError = ip.reply_getError(apiRely)
    bResult = false
    logResult = DoneError
    cancelreply = ip.UUTCancel(uutHandle)
    ip.reply_destroy(cancelreply)
    ip.reply_destroy(reply)
    ip.UID_destroy(uutHandle)
    ResultTable.resultCode = bResult
    ResultTable.resultString = logResult
    return
  end
  local cbVersion = cba.cbSNGetVersion()
  print("cbVersion")
  print(cbVersion)
  iLength1 = 0
  ControlBits,slength4 = cba.ControlBitsToCheckSN(sn,iLength1)
  result,ipControlBitsArray1,slength41,acpControlBitNames4 = cba.ControlBitsToCheckSN(sn,slength4)
  print(result)
  print("result")
  print(acpControlBitNames4)
  if result <= 0 then
    bResult = true
    logResult = "CBs Check is not on or no station to check"
    ResultTable.resultCode = bResult
    ResultTable.resultString = logResult
    return
  end
  print("ipControlBitsArray1")
  print(ipControlBitsArray1)
  for i,j in pairs(ipControlBitsArray1) do
    strStationCBAddress1 = string.format("0x%0.2X",ipControlBitsArray1[i])
    --strStationCBAddress1 = string.format("0x%0.2X",8) --0x08
    local strFind,_,_ = string.match(snRecvStr,strStationCBAddress1 .. " (%a*%s%d*%s%d*%s%d*%s%d*)")
    local resBool = string.match(strFind or " ","Passed") and true or false
    if resBool ~= true then
      bResult = false
      logResult = acpControlBitNames4[i] .. " CB Check Fail"
      ResultTable.resultCode = bResult
      ResultTable.resultString = logResult
      return
    end
  end

  iAllowedFailCount = cba.StationFailCountAllowed();
  iRealFailCount,_,_ = string.match(snRecvStr,myStationCB .. " %a*%s%d*%s(%d*)%s%d*%s%d*") --0x79 CT1 station id
  if iAllowedFailCount < 0 then
    bResult = false
    logResult = "Network CBs Check is not on, or allow fail count < 0"
    ResultTable.resultCode = bResult
    ResultTable.resultString = logResult
    return
  end  
  if iRealFailCount >= iAllowedFailCount then
    bResult = false
    logResult = "UUT Total Fail Count out of Allowed"
    ResultTable.resultCode = bResult
    ResultTable.resultString = logResult
    return
  end

  bResult = true
  logResult = "Pass"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
  return
end
table.insert(TestItems, {name="NetWork CB: Check Previous Station CBs", action=NetWorkCBCPSC})

table.insert(TestItems, {name="Check Battery Voltage Before Test", action=parseStrWithLimit, device = "IPad"})
TestItems[#TestItems].cmdSet = {"pmuadc --sel euphrates --read vbat\n"}
TestItems[#TestItems].limitSet = {lower=3700, upper=4350, Captures = "(%d+%.%d+)"}

--local function itemHawkingPeakPowerTest(self)
--  local bResult = nil
--  local logResult = nil
--  if hawkingstopFail then
--    bResult = false
--    logResult = "Fail"
--  else
--    logResult = 20 * math.log(PeakMagnitudeTable[self.location],10)
--    bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
--    Parametric={subName={low=self.limitSet.lower, value=logResult, high=self.limitSet.upper, result=bResult, priority=0, testName=self.name,SubTestItem="",SubSubTestItem="",failMsg="N/A",TestUnit="N/A"}}
--    table.insert(PDCAInfo,Parametric)
--  end  
--  ResultTable.resultCode = bResult
--  ResultTable.resultString = logResult
--end
--table.insert(TestItems, {name="Hawking Peak Power Tone 1", action=itemHawkingPeakPowerTest, location = 1})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Peak Power Tone 2", action=itemHawkingPeakPowerTest, location = 2})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Peak Power Tone 3", action=itemHawkingPeakPowerTest, location = 3})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Peak Power Tone 4", action=itemHawkingPeakPowerTest, location = 4})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Peak Power Tone 5", action=itemHawkingPeakPowerTest, location = 5})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Peak Power Tone 6", action=itemHawkingPeakPowerTest, location = 6})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Peak Power Tone 7", action=itemHawkingPeakPowerTest, location = 7})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--local function itemHawkingNoiseMarginTest(self)
--  local bResult = nil
--  local logResult = nil
--  if hawkingstopFail then
--    bResult = false
--    logResult = "Fail"
--  else
--    local _,_,NoisePSD = string.find(rtRecvHawking or "","Average Noise PSD:%s+(.-)%s")
--    logResult = 20 * math.log(PeakMagnitudeTable[self.location],10) - NoisePSD
--    bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
--    Parametric={subName={low=self.limitSet.lower, value=logResult, high=self.limitSet.upper, result=bResult, priority=0, testName=self.name,SubTestItem="",SubSubTestItem="",failMsg="N/A",TestUnit="N/A"}}
--    table.insert(PDCAInfo,Parametric)
--  end  
--  ResultTable.resultCode = bResult
--  ResultTable.resultString = logResult
--end
--table.insert(TestItems, {name="Hawking Noise Margin Tone 1", action=itemHawkingNoiseMarginTest, location = 1})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Noise Margin Tone 2", action=itemHawkingNoiseMarginTest, location = 2})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Noise Margin Tone 3", action=itemHawkingNoiseMarginTest, location = 3})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Noise Margin Tone 4", action=itemHawkingNoiseMarginTest, location = 4})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Noise Margin Tone 5", action=itemHawkingNoiseMarginTest, location = 5})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Noise Margin Tone 6", action=itemHawkingNoiseMarginTest, location = 6})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

--table.insert(TestItems, {name="Hawking Noise Margin Tone 7", action=itemHawkingNoiseMarginTest, location = 7})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA"}

local function itemHawkingSomeValueTest(self)
  local bResult = nil
  local logResult = nil
  if hawkingstopFail then
    bResult = false
    logResult = "Fail"
  else
    _,_,logResult = string.find(rtRecvHawking or "",self.limitSet.Captures)
    bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
    Parametric={subName={low=self.limitSet.lower, value=logResult, high=self.limitSet.upper, result=bResult, priority=0, testName=self.name,SubTestItem="",SubSubTestItem="",failMsg="N/A",TestUnit="N/A"}}
    table.insert(PDCAInfo,Parametric)
  end  
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
--table.insert(TestItems, {name="Hawking DC Magnitude", action=itemHawkingSomeValueTest})
--TestItems[#TestItems].limitSet = {lower="NA", upper="NA", Captures = "DC Magnitude=(.-)%s"}
local function item2xLEDStrobetorchMode(self)
  local rtSendTmp,rtRecvTmp = doDiagsCmd("camisp --find\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x01 1 1 0x00\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x01 1 1 0x00\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cread 0 0x63 0x0C 1 1\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cread 1 0x67 0x0C 1 1\n")  
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x02 1 1 0x5B\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x02 1 1 0x5B\n")
  rtSendTmp,rtRecvTmp = doScorpiusCmd("flashon\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x05 1 1 0x47\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x05 1 1 0x47\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x01 1 1 0x09\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x01 1 1 0x09\n")
  local rtSendflash,rtRecvflash = doScorpiusCmd("readflash\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("wait 200\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x01 1 1 0x00\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x01 1 1 0x00\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("camisp --exit\n")
  local _,_,logResult = string.find(rtRecvflash or " ","(%d+)")
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  Parametric={subName={low=self.limitSet.lower, value=logResult, high=self.limitSet.upper, result=bResult, priority=0, testName=self.name,SubTestItem="",SubSubTestItem="",failMsg="N/A",TestUnit="N/A"}}
  table.insert(PDCAInfo,Parametric)
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="2x Cool LED strobe torch mode (lux)", action=item2xLEDStrobetorchMode})
TestItems[#TestItems].limitSet = {lower=20000, upper="NA"}

local function item2xAmberLEDStrobetorchMode(self)
  local rtSendTmp,rtRecvTmp = doDiagsCmd("camisp --find\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x01 1 1 0x00\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x01 1 1 0x00\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cread 0 0x63 0x0C 1 1\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cread 1 0x67 0x0C 1 1\n")  
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x02 1 1 0x5B\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x02 1 1 0x5B\n")
  rtSendTmp,rtRecvTmp = doScorpiusCmd("flashon\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x06 1 1 0x47\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x06 1 1 0x47\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x01 1 1 0x0A\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x01 1 1 0x0A\n")
  local rtSendflash,rtRecvflash = doScorpiusCmd("readflash\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("wait 200\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 0 0x63 0x01 1 1 0x00\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("time camisp --i2cwrite 1 0x67 0x01 1 1 0x00\n")
  rtSendTmp,rtRecvTmp = doDiagsCmd("camisp --exit\n")
  local _,_,logResult = string.find(rtRecvflash or " ","(%d+)")
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  Parametric={subName={low=self.limitSet.lower, value=logResult, high=self.limitSet.upper, result=bResult, priority=0, testName=self.name,SubTestItem="",SubSubTestItem="",failMsg="N/A",TestUnit="N/A"}}
  table.insert(PDCAInfo,Parametric)
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="2x Amber LED strobe torch mode (lux)", action=item2xAmberLEDStrobetorchMode})
TestItems[#TestItems].limitSet = {lower=20000, upper="NA"}

table.insert(TestItems, {name="Check Battery Level After Test", action=parseStrWithLimit, device = "IPad"})
TestItems[#TestItems].cmdSet = {"device -k GasGauge -g charge-percentage\n"}
TestItems[#TestItems].limitSet = {lower=0, upper=101, Captures = "(%d+)"}

table.insert(TestItems, {name="Check Battery Voltage After Test", action=parseStrWithLimit, device = "IPad"})
TestItems[#TestItems].cmdSet = {"pmuadc --sel euphrates --read vbat\n"}
TestItems[#TestItems].limitSet = {lower=3700, upper=4350, Captures = "(%d+.%d+)"}

--[[
local function itemEnterUSB2ACC1HighCurMode(self)
  doDiagsCmd("accessory -m off\n")
  local rtSend,rtRecv = doDiagsCmd("accessory -p acc1\n")
  
  local bResult = string.match(rtRecv or " ",self.specSet.spec) and true or false
  ResultTable.resultCode = bResult
end
table.insert(TestItems, {name="Enter USB2 ACC1 high current mode", action=itemEnterUSB2ACC1HighCurMode})
TestItems[#TestItems].specSet = {spec = "OK"}

local function itemUSB2ACC1HighCurWithoutLoad(self)
  
  doDiagsCmd("accessory -m bypass\n")
  doScorpiusCmd("E5OFF\n")
  doScorpiusCmd("ELOFF\n")
  local  rtSend100,rtRecv100 = doScorpiusCmd("GETACC31\n")
  local _,_,logResult = string.find(rtRecv100 or "",self.limitSet.Captures)
 
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
table.insert(TestItems, {name="USB2 ACC1 0.25A voltage without load", action=itemUSB2ACC1HighCurWithoutLoad})
TestItems[#TestItems].limitSet = {lower=3400, upper=4400, Captures = ":(%d+)%smV"}

local function itemUSB2ACC1HighCurModeCurrent(self)
  --if string.find( self.name or "",-----lorne 20160715 08:25
  doScorpiusCmd("E1ON\n")
  doScorpiusCmd("ELON\n")
  doScorpiusCmd("E2_5ON\n")
  local rtSend,rtRecv = doScorpiusCmd("GETACC2\n")
  local _,_,ACC1Current = string.find(rtRecv or "",":(%d+.%d+)")
  USB2ACC1Bypass500high = ACC1Current
  local  rtSendF,rtRecvF = doScorpiusCmd("GETACC31\n")
  _,_,volldo3 = string.find(rtRecvF or "",":(%d+)%smV")
  volldonor33 = volldo3
  local rtSend101,rtRecv101 = doDiagsCmd("pmurw --read 0x2E00\n")
  _,_,overcur3 = string.find(rtRecv101 or "",":%s+(.-)%s")
  
  local rtSendVH,rtRecvVH = doDiagsCmd("pmuadc --read vddout\n")
  _,_,vddouthigh2 = string.find(rtRecvVH or "", ":%s+(%d+.%d+)%smV")
  
  local bResult = compareAandB(ACC1Current,self.limitSet.lower,self.limitSet.upper,true)
  
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = ACC1Current or "No Data"
end
table.insert(TestItems, {name="USB2 ACC1 high current mode current", action=itemUSB2ACC1HighCurModeCurrent})
TestItems[#TestItems].limitSet = {lower=230, upper=270}

local function itemUSB2ACC1HighCurWithLoad(self)
  local bResult = compareAandB(volldo3,self.limitSet.lower,self.limitSet.upper,true)
   ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = volldo3 or "No Data"
end
table.insert(TestItems, {name="USB2 ACC1 0.25A mode voltage with load (mV)", action=itemUSB2ACC1HighCurWithLoad, device = "Fixture"})
TestItems[#TestItems].limitSet = {lower=2900, upper=4400}

local function itemEnterUSB2ACC1StatusCheck(self)
  local bResult = string.match(overcur3 or " ","0x00") and true or false
  ResultTable.resultCode = bResult
end
table.insert(TestItems, {name="USB2 ACC1 Over Current status check", action=itemEnterUSB2ACC1StatusCheck})


local function itemBattACC1Drop1250mA(self)
  if tonumber(vddouthigh2) == nil or tonumber(volldonor33) == nil then
    ResultTable.resultCode = false
    return
  end  
  local logResult = tonumber(vddouthigh2) - tonumber(volldonor33)
  usb2ACC1dropVOT2 = logResult
  local bResult = logResult and true or false
  ResultTable.lowLimit = "NA"
  ResultTable.UpLimit = "NA"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="VCC_main ACC1 voltage drop with 0.25A (mV)", action=itemBattACC1Drop1250mA})

local function itemVCCMainBattDCR(self)
  if tonumber(usb2ACC1dropVOT2) == nil or tonumber(USB2ACC1Bypass500high) == nil or tonumber(USB2ACC1Bypass500high) == 0 then
    ResultTable.resultCode = false
    return
  end  
  local logResult = (tonumber(usb2ACC1dropVOT2) / tonumber(USB2ACC1Bypass500high)) * 1000
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
table.insert(TestItems, {name="VCC_main ACC1 high current mode DCR", action=itemVCCMainBattDCR})
TestItems[#TestItems].limitSet = {lower=220, upper=700}

local function itemUSB2ACC1CurrentStausCheck(self)
  doScorpiusCmd(self.cmdSet[1])
  doScorpiusCmd("GETACC31\n")
  doScorpiusCmd("GETACC2\n")
  local rtSend,rtRecv = doDiagsCmd("pmurw --read 0x2E00\n")
  local _,_,logResult = string.find(rtRecv or "",":%s+(.-)%s")
  ResultTable.resultCode = logResult and true or false
  ResultTable.resultString = logResult
 end
table.insert(TestItems, {name="USB2 ACC1 0.35A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E3_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 0.45A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E4_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 0.55A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E5_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 0.65A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E6_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 0.75A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E7_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 0.95A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E9_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 1.05A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E10_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 1.15A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E11_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 1.25A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E12_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 1.35A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E13_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 1.45A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E14_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 1.55A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E15_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 1.65A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E16_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 1.85A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E18_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 1.95A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E19_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 2.05A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E20_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 2.15A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E21_5ON\n"}
 
table.insert(TestItems, {name="USB2 ACC1 2.25A Over Current status check", action=itemUSB2ACC1CurrentStausCheck})
TestItems[#TestItems].cmdSet = {"E22_5ON\n"}
--]]
--------------------Removed 20161029 start--------------

local function itemBattACC1LD0DCR(self)
  if tonumber( ACC1LDOvoltdrop) == nil or tonumber(USB2ACC1LDOcurrent) == nil then
    ResultTable.resultCode = false
    return
  end  
  local logResult = (ACC1LDOvoltdrop / USB2ACC1LDOcurrent) * 1000
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  
  doDiagsCmd("accessory -p acc1\n")
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
table.insert(TestItems, {name="VCC_main to E75U ACC1 LDO DCR", action=itemBattACC1LD0DCR})
TestItems[#TestItems].limitSet = {lower=3000, upper=11500}


local function itemBattACC2E75UACC2LDODCR(self)
  if tonumber(USB2ACC2LDOdrip) == nil or tonumber(USB2ACC2LDO100) == nil or  tonumber(USB2ACC2LDO100) == 0 then
    ResultTable.resultCode = false
    return
  end 
  local logResult = (tonumber( USB2ACC2LDOdrip) / tonumber( USB2ACC2LDO100)) * 1000
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
table.insert(TestItems, {name="VCC_main to E75U ACC2 LDO DCR", action=itemBattACC2E75UACC2LDODCR})
TestItems[#TestItems].limitSet = {lower=3000, upper=11500}

local function itemEnterUSB2ACC2HighCurMode(self)
  doDiagsCmd("accessory -m off\n")
  local rtSendTmpValue,rtRecvTmpValue = doDiagsCmd("accessory -p acc2\n")
  --doDiagsCmd("accessory -m bypass\n")
  local bResult = string.find(rtRecvTmpValue or "","OK") and true or false
  
  ResultTable.resultCode = bResult
end
table.insert(TestItems, {name="Enter USB2 ACC2 high current mode", action=itemEnterUSB2ACC2HighCurMode})

local function itemUSB2ACC2HighCurWithoutLoad(self)
  doDiagsCmd("accessory -m bypass\n")
  doScorpiusCmd("E1OFF\n")
  doScorpiusCmd("ELOFF\n")
  local rtSend100,rtRecv100 = doScorpiusCmd("GETACC41\n")
  local _,_,logResult = string.find(rtRecv100 or "",(":(%d+)%smV"))
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
table.insert(TestItems, {name="USB2 ACC2 500mA voltage without load (mV)", action=itemUSB2ACC2HighCurWithoutLoad})
TestItems[#TestItems].limitSet = {lower=3400, upper=4400}

local function itemUSB2ACC2HighCurModeCurrent(self)
  doScorpiusCmd("E1ON\n")
  doScorpiusCmd("ELON\n")
  doScorpiusCmd("E5ON\n")
  local rtSend,rtRecv = doScorpiusCmd("GETACC2\n")
  rtSend,volldo412 = doScorpiusCmd("GETACC41\n")
  
  rtSend101,rtRecv101 = doDiagsCmd("pmurw --read 0x2E00\n")
  local _,_,logResult = string.find(rtRecv or "","(%d+.%d+)")
  USB2ACC2Bypass500high = logResult
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)

  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
table.insert(TestItems, {name="USB2 ACC2 high current mode current", action=itemUSB2ACC2HighCurModeCurrent})
TestItems[#TestItems].limitSet = {lower=485, upper=515}

local function itemUSB2ACC2HighCurWithLoad(self)
  local _,_,logResult = string.find(volldo412 or "",self.limitSet.Captures)
  volldonor41with = logResult
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
table.insert(TestItems, {name="USB2 ACC2 500mA mode voltage with load", action=itemUSB2ACC2HighCurWithLoad})
TestItems[#TestItems].limitSet = {lower=2900, upper=4400, Captures = ":(%d+)"}

local function itemEnterUSB2ACC2StatusCheck(self)
  --rtRecv101 com from 99 test item
  local bResult = string.match(rtRecv101 or " ",self.specSet.spec) and true or false
  ResultTable.resultCode = bResult
end
table.insert(TestItems, {name="USB2 ACC2 Over Current status check", action=itemEnterUSB2ACC2StatusCheck})
TestItems[#TestItems].specSet = {spec = "0x00"}

local function itemBattACC2Drop1250mA(self)
  local rtSend,rtRecv =doDiagsCmd("pmuadc --read vddout\n") 
  _,_,USB2ACC2high22 = string.find(rtRecv or "",":%s+(%d+.%d+)%s+mV")
  if tonumber(USB2ACC2high22) == nil or tonumber(volldonor41with) == nil then
    ResultTable.resultCode = false
    return
  end
  local logResult = tonumber(USB2ACC2high22) - tonumber(volldonor41with)
  usb2ACC2dropVOT2 = logResult
  local bResult = logResult and true or false
  ResultTable.lowLimit = "NA"
  ResultTable.UpLimit = "NA"
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult
end
table.insert(TestItems, {name="VCC_main ACC2 voltage drop with 500mA", action=itemBattACC2Drop1250mA})

local function itemVCCMainBattACC2DCR(self)
  if tonumber( usb2ACC2dropVOT2) == nil or tonumber( USB2ACC2Bypass500high) == nil or tonumber(USB2ACC2Bypass500high) == 0 then
    ResultTable.resultCode = false
    return
  end  
  local logResult = (tonumber( usb2ACC2dropVOT2 )/ tonumber( USB2ACC2Bypass500high ))* 1000
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  
  ResultTable.resultCode = bResult
  ResultTable.resultString =tostring( logResult) or "No Data"
end
table.insert(TestItems, {name="VCC_main ACC2 high current mode DCR", action=itemVCCMainBattACC2DCR})
TestItems[#TestItems].limitSet = {lower=220, upper=700}


table.insert(TestItems, {name="USB2 ACC2 0.35A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E3_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 0.45A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E4_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 0.55A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E5_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 0.65A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E6_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 0.75A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E7_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 0.95A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E9_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 1.05A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E10_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 1.15A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E11_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 2.05A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E20_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 2.15A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E21_5ON\n"})

table.insert(TestItems, {name="USB2 ACC2 2.25A Over Current status check", action=itemUSB2ACC2OverCurrentStatusCheck,cmdSet = "E22_5ON\n"})

--------------------Removed 20161029 end----------------


--table.insert(TestItems, {name="Burn Device Color", action=itemBurnDeviceColor})
--TestItems[#TestItems].cmdSet = {"syscfg add DClr "}

--table.insert(TestItems, {name="Read Back Device Color", action=getInfoFromUnit, Captures = "syscfg print DClr%s+(.+)%s+%["})
--TestItems[#TestItems].cmdSet = {"syscfg print DClr\n"}

--table.insert(TestItems, {name="Read Back Matrix and Special Builds", action=getInfoFromUnit, Captures = "syscfg print CFG#%s+(.+)%s+%["})
--TestItems[#TestItems].cmdSet = {"syscfg print CFG#\n"}


--table.insert(TestItems, {name="Orion output 250mA mode voltage w/o load (mV)", action=itemOrionOutputModeVoltageWO})
--TestItems[#TestItems].limitSet = {lower=3300, upper=5000}
--TestItems[#TestItems].cmdSet = {"i2c -v 1 0x13 0x02 0x01\n"}

--table.insert(TestItems, {name="Orion output 250mA mode current (mV)", action=itemOrionOutputModeCurrent})
--TestItems[#TestItems].limitSet = {lower=220, upper=280}
--TestItems[#TestItems].cmdSet = {"[EL-187]\n"}

--table.insert(TestItems, {name="Orion output 250mA mode voltage w/ load (mV)", action=itemOrionOutputModeVoltageW})
--TestItems[#TestItems].limitSet = {lower=3300, upper=5000}

local function itemOrionDetectionGND40K(self)
  doOrionCmd("[GPIO_WR-C-F-0]\n")
  app.wait(150)
  table.insert(ResultLog,"Delay 150ms\n")
  doOrionCmd("[GPIO_WR-A-C-1]\n")
  app.wait(50)
  table.insert(ResultLog,"Delay 50ms\n")
  doDiagsCmd("i2c -v 1 0x13 0xA0 0x0D\n")
  app.wait(50)
  table.insert(ResultLog,"Delay 50ms\n")
  local rtSend1,rtRecv1 = doDiagsCmd("i2c -d 1 0x13 0xA5 1\n")
  local rtSend2,rtRecv2 = doDiagsCmd("i2c -d 1 0x13 0xA4 1\n")
  if rtRecv1 == nil or rtRecv2 == nil then
    ResultTable.resultCode = false
    return
  end  
  local _,_,cm1 = string.find(rtRecv1 or " ", "Data:%s+(.-)%s") 
  local _,_,cmd2 = string.find(rtRecv2 or " ", "Data:%s+(.-)%s")
  local logResult = (tonumber(cm1&0x0f) <<8 | tonumber(cmd2>>4) <<4 | tonumber(cmd2&0x0f))*1.173
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
--table.insert(TestItems, {name="Orion Contamination Detection 4uA DATA_GND_40K", action=itemOrionDetectionGND40K})
--TestItems[#TestItems].limitSet = {lower=80, upper=240}

local function itemOrionDetectionGND20K(self)
  doOrionCmd("[GPIO_WR-A-C-0]\n")
  app.wait(150)
  table.insert(ResultLog,"Delay 150ms\n")
  doOrionCmd("[GPIO_WR-A-B-1]\n")
  app.wait(50)
  table.insert(ResultLog,"Delay 50ms\n")
  doDiagsCmd("i2c -v 1 0x13 0xA0 0x0D\n")
  app.wait(50)
  table.insert(ResultLog,"Delay 50ms\n")
  local rtSend1,rtRecv1 = doDiagsCmd("i2c -d 1 0x13 0xA5 1\n")
  local rtSend2,rtRecv2 = doDiagsCmd("i2c -d 1 0x13 0xA4 1\n")
  if rtRecv1 == nil or rtRecv2 == nil then
    ResultTable.resultCode = false
    return
  end
  local _,_,cm1 = string.find(rtRecv1 or " ", "Data:%s+(.-)%s") 
  local _,_,cmd2 = string.find(rtRecv2 or " ", "Data:%s+(.-)%s")
  local logResult = (tonumber(cm1&0x0f) <<8 | tonumber(cmd2>>4) <<4 | tonumber(cmd2&0x0f))*1.173
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
--table.insert(TestItems, {name="Orion Contamination Detection 4uA DATA_GND_20K", action=itemOrionDetectionGND20K})
--TestItems[#TestItems].limitSet = {lower=30, upper=130}

local function itemOrionDetectionPWR40K(self)
  doOrionCmd("[GPIO_WR-C-F-0]\n")
  app.wait(150)
  table.insert(ResultLog,"Delay 150ms\n")
  doOrionCmd("[GPIO_WR-A-C-1]\n")
  app.wait(150)
  table.insert(ResultLog,"Delay 150ms\n")
  doDiagsCmd("i2c -v 1 0x13 0xA0 0x0D\n")
  app.wait(150)
  table.insert(ResultLog,"Delay 150ms\n")
  local rtSend1,rtRecv1 = doDiagsCmd("i2c -d 1 0x13 0xA5 1\n")
  local rtSend2,rtRecv2 = doDiagsCmd("i2c -d 1 0x13 0xA4 1\n")
  if rtRecv1 == nil or rtRecv2 == nil then
    ResultTable.resultCode = false
    return
  end
  local _,_,cm1 = string.find(rtRecv1 or " ", "Data:%s+(.-)%s") 
  local _,_,cmd2 = string.find(rtRecv2 or " ", "Data:%s+(.-)%s")
  local logResult = (tonumber(cm1&0x0f) <<8 | tonumber(cmd2>>4) <<4 | tonumber(cmd2&0x0f))*1.173
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
--table.insert(TestItems, {name="Orion Contamination Detection 4uA DATA_PWR_40K", action=itemOrionDetectionPWR40K})
--TestItems[#TestItems].limitSet = {lower=80, upper=240}

local function itemOrionDetectionPWR20K(self)
  doOrionCmd("[GPIO_WR-A-C-0]\n")
  app.wait(150)
  table.insert(ResultLog,"Delay 150ms\n")
  doOrionCmd("[GPIO_WR-A-B-1]\n")
  app.wait(150)
  table.insert(ResultLog,"Delay 150ms\n")
  doDiagsCmd("i2c -v 1 0x13 0xA0 0x0D\n")
  app.wait(150)
  table.insert(ResultLog,"Delay 150ms\n")
  local rtSend1,rtRecv1 = doDiagsCmd("i2c -d 1 0x13 0xA5 1\n")
  local rtSend2,rtRecv2 = doDiagsCmd("i2c -d 1 0x13 0xA4 1\n")
  if rtRecv1 == nil or rtRecv2 == nil then
    ResultTable.resultCode = false
    return
  end
  local _,_,cm1 = string.find(rtRecv1 or " ", "Data:%s+(.-)%s") 
  local _,_,cmd2 = string.find(rtRecv2 or " ", "Data:%s+(.-)%s")
  local logResult = (tonumber(cm1&0x0f) <<8 | tonumber(cmd2>>4) <<4 | tonumber(cmd2&0x0f))*1.173
  local bResult = compareAandB(logResult,self.limitSet.lower,self.limitSet.upper,true)
  ResultTable.lowLimit = self.limitSet.lower
  ResultTable.UpLimit = self.limitSet.upper
  ResultTable.resultCode = bResult
  ResultTable.resultString = logResult or "No Data"
end
--table.insert(TestItems, {name="Orion Contamination Detection 4uA DATA_PWR_20K", action=itemOrionDetectionPWR20K})
--TestItems[#TestItems].limitSet = {lower=30, upper=130}


local function item24KSPKL1_CN_L(self)
  if iPadSerial == nil then
    ResultTable.resultCode = false
    return
  end  
  doScorpiusCmd("mic1 on\n")
  doScorpiusCmd("MIC Wave Short\n")
  doDiagsCmd("audio --reset\n")
  doDiagsCmd("audioparam --set --block spkl1 --param enable-mon --value true\n")
  doDiagsCmd("audioparam --set --block spkl1 --param ch-vmon --value 0\n")
  doDiagsCmd("audioparam --set --block spkl1 --param ch-imon --value 1\n")
  doDiagsCmd("audioreg -b spkl1 -w -a 0x001A -d 0xF3\n")
  doDiagsCmd("audioreg -b spkl1 -w -a 0x001C -d 0x0C\n")
  doDiagsCmd("audioreg -r -b spkl1 -a 0x001A -l 4\n")
  doDiagsCmd("routeaudio -b spkl1 -i spk-i2s -o spk-out -r\n")
  doDiagsCmd("processaudio --freebufs all\n")
  doDiagsCmd("audioparam -b socmca -p ap-mca2 -s -n master-lrclk-enable -v false\n")
  local rtSend = iPadSerial:send("loopaudio -b socmca --txport ap-mca2 --rxport ap-mca2 --bitdepth 32 --rate 48000 --len 1500 --freq 2400 -c8\n")
  local SendaLog = string.format("send[%s]:%s", (rtSend==0 and "Success" or "Fail"), "loopaudio -b socmca --txport ap-mca2 --rxport ap-mca2 --bitdepth 32 --rate 48000 --len 1500 --freq 2400 -c8" or "cmd empty\n")
  local rtRecv = iPadSerial:recv({"Receiving"},1)
  local RecaLog = string.format("recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
  table.insert(ResultLog,SendaLog)
  table.insert(ResultLog,RecaLog)
  local rtSendLSPK1,rtRecvLSPKL1 = doScorpiusCmd("GetAudioF\n")
  rtRecv = iPadSerial:recv(":-) ",15)
  app.wait(1500)
  table.insert(ResultLog,"Wait 1500ms\n")
  doDiagsCmd("processaudio -p crop -i looprx0 -o \"--start 5000\"\n")
  _,ComTable["rtRecvf"] = doDiagsCmd("processaudio -p fft -i process0 -o \"--normalize false --peakBinWidth 3\"\n")
  _,ComTable["rtRecvt"] = doDiagsCmd("processaudio -p rms -i process0\n")

  rtRecv = string.match(rtRecvLSPKL1 or "","([%d%p]+)%s*Hz")
  local lowerlim,upperlim = self.lower,self.upper
  local bResult = compareAandB(rtRecv,lowerlim,upperlim,true)
  ResultTable.lowLimit = lowerlim
  ResultTable.UpLimit = upperlim
  ResultTable.resultCode = bResult
  ResultTable.resultString = rtRecv or "no data"
end
--table.insert(TestItems, {name="2.4K Tone To SPKL1_CN_L", action=item24KSPKL1_CN_L,lower=2300, upper=2500})

--[[
table.insert(TestItems, {name="SPKL1_CN_L VMON_CH0_FFT Peak Magnitude", action=SpkMatch,match1="Channel 0:\n(.-)\nOK",match2="Peak Magnitude=(.-);"})
table.insert(TestItems, {name="SPKL1_CN_L VMON_CH0_Frequency", action=SpkMatch,match1="Channel 0:\n(.-)\nOK",match2="Frequency:%s+(.-)%s",lower=2350,upper=2450})
table.insert(TestItems, {name="SPKL1_CN_L VMON_CH0_SINAD", action=SpkMatch,match1="Channel 0:\n(.-)\nOK",match2="SINAD=(.-)%s",lower=15,upper="NA"})
table.insert(TestItems, {name="SPKL1_CN_L VMON_CH0_THD+N", action=SpkMatch,match1="Channel 0:\n(.-)\nOK",match2="THD%+N:%s+(.-)%s",lower="NA",upper=-55})
table.insert(TestItems, {name="SPKL1_CN_L VMON_CH0_RMS (Root-Mean-Square)", action=SpkMatch,match1="Channel 0:\n(.-)\nOK",match2="RMS %(Root%-Mean%-Square%):%s+(.-)%s"})

table.insert(TestItems, {name="SPKL1_CN_L IMON_CH1_FFT Peak Magnitude", action=SpkMatch,match1="Channel 1:\n(.-)\nOK",match2="Peak Magnitude=(.-);"})
table.insert(TestItems, {name="SPKL1_CN_L IMON_CH1_Frequency", action=SpkMatch,match1="Channel 1:\n(.-)\nOK",match2="Frequency:%s+(.-)%s",lower=2350,upper=2450})
table.insert(TestItems, {name="SPKL1_CN_L IMON_CH1_SINAD", action=SpkMatch,match1="Channel 1:\n(.-)\nOK",match2="SINAD=(.-)%s",lower=15,upper="NA"})
table.insert(TestItems, {name="SPKL1_CN_L IMON_CH1_THD+N", action=SpkMatch,match1="Channel 1:\n(.-)\nOK",match2="THD%+N:%s+(.-)%s",lower="NA",upper=-47})
table.insert(TestItems, {name="SPKL1_CN_L IMON_CH1_RMS (Root-Mean-Square)", action=SpkMatch,match1="Channel 1:\n(.-)\nOK",match2="RMS %(Root%-Mean%-Square%):%s+(.-)%s"})


local function item24KSPKR1_CN_R(self)
  if iPadSerial == nil then
    ResultTable.resultCode = false
    return
  end    
  doScorpiusCmd("MIC1 OFF\n")
  doScorpiusCmd("mic2 on\n")
  doScorpiusCmd("MIC Wave Short\n")
  doDiagsCmd("audio --reset\n")
  doDiagsCmd("audioparam --set --block spkr1 --param enable-mon --value true\n")
  doDiagsCmd("audioparam --set --block spkr1 --param ch-vmon --value 2\n")
  doDiagsCmd("audioparam --set --block spkr1 --param ch-imon --value 3\n")
  doDiagsCmd("audioreg -b spkr1 -w -a 0x001A -d 0xFC\n")
  doDiagsCmd("audioreg -b spkr1 -w -a 0x001C -d 0x03\n")
  doDiagsCmd("audioreg -r -b spkr1 -a 0x001A -l 4\n")
  doDiagsCmd("routeaudio -b spkr1 -i spk-i2s -o spk-out -r\n")
  doDiagsCmd("processaudio --freebufs all\n")
  doDiagsCmd("audioparam -b socmca -p ap-mca2 -s -n master-lrclk-enable -v false\n")
  local cmd = "loopaudio -b socmca --txport ap-mca2 --rxport ap-mca2 --bitdepth 32 --rate 48000 --len 1500 --freq 2400 -c8\n"
  local rtSend = iPadSerial:send(cmd)
  local SendaLog = string.format("send[%s]:%s", (rtSend==0 and "Success" or "Fail"), cmd or "cmd empty\n")
  local rtRecv = iPadSerial:recv({"Receiving"},1)
  local RecaLog = string.format("recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
  table.insert(ResultLog,SendaLog)
  table.insert(ResultLog,RecaLog)
  local rtSendLSPK1,rtRecvLSPKL1 = doScorpiusCmd("GetAudioF\n")
  rtRecv = iPadSerial:recv(":-) ",15)
  app.wait(1500)
  table.insert(ResultLog,"Wait 1500ms\n")
  doDiagsCmd("processaudio -p crop -i looprx0 -o \"--start 5000\"\n")
  _,ComTable["rtRecvf"] = doDiagsCmd("processaudio -p fft -i process0 -o \"--normalize false --peakBinWidth 3\"\n")
  _,ComTable["rtRecvt"] = doDiagsCmd("processaudio -p rms -i process0\n")
    rtRecv = string.match(rtRecvLSPKL1 or "","([%d%p]+)%s*Hz")
  local lowerlim,upperlim = self.lower,self.upper
  local bResult = compareAandB(rtRecv,lowerlim,upperlim,true)
  ResultTable.lowLimit = lowerlim
  ResultTable.UpLimit = upperlim
  ResultTable.resultCode = bResult
  ResultTable.resultString = rtRecv or "no data"
end
table.insert(TestItems, {name="2.4K Tone To SPKR1_CN_R", action=item24KSPKR1_CN_R,lower=2300, upper=2500})



table.insert(TestItems, {name="SPKR1_CN_R VMON_CH2_FFT Peak Magnitude", action=SpkMatch,match1="Channel 2:\n(.-)\n",match2="Peak Magnitude=(.-);"})
table.insert(TestItems, {name="SPKR1_CN_R VMON_CH2_Frequency", action=SpkMatch,match1="Channel 2:\n(.-)\nOK",match2="Frequency:%s+(.-)%s",lower=2350,upper=2450})
table.insert(TestItems, {name="SPKR1_CN_R VMON_CH2_SINAD", action=SpkMatch,match1="Channel 2:\n(.-)\nOK",match2="SINAD=(.-)%s",lower=15,upper="NA"})
table.insert(TestItems, {name="SPKR1_CN_R VMON_CH2_THD+N", action=SpkMatch,match1="Channel 2:\n(.-)\nOK",match2="THD%+N:%s+(.-)%s",lower="NA",upper=-55})
table.insert(TestItems, {name="SPKR1_CN_R VMON_CH2_RMS (Root-Mean-Square)", action=SpkMatch,match1="Channel 2:\n(.-)\nOK",match2="RMS %(Root%-Mean%-Square%):%s+(.-)%s"})

table.insert(TestItems, {name="SPKR1_CN_R IMON_CH3_FFT Peak Magnitude", action=SpkMatch,match1="Channel 3:\n(.-)\nOK",match2="Peak Magnitude=(.-);"})
table.insert(TestItems, {name="SPKR1_CN_R IMON_CH3_Frequency", action=SpkMatch,match1="Channel 3:\n(.-)\nOK",match2="Frequency:%s+(.-)%s",lower=2350,upper=2450})
table.insert(TestItems, {name="SPKR1_CN_R IMON_CH3_SINAD", action=SpkMatch,match1="Channel 3:\n(.-)\nOK",match2="SINAD=(.-)%s",lower=15,upper="NA"})
table.insert(TestItems, {name="SPKR1_CN_R IMON_CH3_THD+N", action=SpkMatch,match1="Channel 3:\n(.-)\nOK",match2="THD%+N:%s+(.-)%s",lower="NA",upper=-47})
table.insert(TestItems, {name="SPKR1_CN_R IMON_CH3_RMS (Root-Mean-Square)", action=SpkMatch,match1="Channel 3:\n(.-)\nOK",match2="RMS %(Root%-Mean%-Square%):%s+(.-)%s"})



local function item24KSPKL2_CN_L(self)
  if iPadSerial == nil then
    ResultTable.resultCode = false
    return
  end  
  doScorpiusCmd("MIC2 OFF\n")
  doScorpiusCmd("mic3 on\n")
  doScorpiusCmd("MIC Wave Short\n")
  doDiagsCmd("audio --reset\n")
  doDiagsCmd("audioreg -b audmux -w -a 0x1C -d 0x000180909\n")
  doDiagsCmd("audioparam --set --block spkl2 --param enable-mon --value true\n")
  doDiagsCmd("audioparam --set --block spkl2 --param ch-vmon --value 4\n")
  doDiagsCmd("audioparam --set --block spkl2 --param ch-imon --value 5\n")
  doDiagsCmd("audioreg -b spkl2 -w -a 0x001A -d 0x3F\n")
  doDiagsCmd("audioreg -b spkl2 -w -a 0x001C -d 0xC0\n")
  doDiagsCmd("audioreg -r -b spkl2 -a 0x001A -l 4\n")
  doDiagsCmd("routeaudio -b spkl2 -i spk-i2s -o spk-out -r\n")
  doDiagsCmd("processaudio --freebufs all\n")
  doDiagsCmd("audioparam -b socmca -p ap-mca2 -s -n master-lrclk-enable -v false\n")
  local rtSend = iPadSerial:send("loopaudio -b socmca --txport ap-mca2 --rxport ap-mca2 --bitdepth 32 --rate 48000 --len 1500 --freq 2400 -c8\n")
  local SendaLog = string.format("send[%s]:%s", (rtSend==0 and "Success" or "Fail"), rtSend or "cmd empty\n")
  local rtRecv = iPadSerial:recv({"Receiving"},1)
  local RecaLog = string.format("recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
  table.insert(ResultLog,SendaLog)
  table.insert(ResultLog,RecaLog)
  local rtSendLSPK1,rtRecvLSPKL1 = doScorpiusCmd("GetAudioF\n")
  rtRecv = iPadSerial:recv(":-) ",15)
  app.wait(1500)
  table.insert(ResultLog,"Wait 1500ms\n")
  doDiagsCmd("processaudio -p crop -i looprx0 -o \"--start 5000\"\n")
  _,ComTable["rtRecvf"] = doDiagsCmd("processaudio -p fft -i process0 -o \"--normalize false --peakBinWidth 3\"\n")
  _,ComTable["rtRecvt"] = doDiagsCmd("processaudio -p rms -i process0\n")
  
  rtRecv = string.match(rtRecvLSPKL1 or "","([%d%p]+)%s*Hz")
  local lowerlim,upperlim = self.lower,self.upper
  local bResult = compareAandB(rtRecv,lowerlim,upperlim,true)
  ResultTable.lowLimit = lowerlim
  ResultTable.UpLimit = upperlim
  ResultTable.resultCode = bResult
  ResultTable.resultString = rtRecv or "no data"
end
table.insert(TestItems, {name="2.4K Tone To SPKL2_FH_L", action=item24KSPKL2_CN_L,lower=2300, upper=2500})


table.insert(TestItems, {name="SPKL2_FH_L VMON_CH4_FFT Peak Magnitude", action=SpkMatch,match1="Channel 4:\n(.-)\nOK",match2="Peak Magnitude=(.-);"})
table.insert(TestItems, {name="SPKL2_FH_L VMON_CH4_Frequency", action=SpkMatch,match1="Channel 4:\n(.-)\nOK",match2="Frequency:%s+(.-)%s",lower=2350,upper=2450})
table.insert(TestItems, {name="SPKL2_FH_L VMON_CH4_SINAD", action=SpkMatch,match1="Channel 4:\n(.-)\nOK",match2="SINAD=(.-)%s",lower=15,upper="NA"})
table.insert(TestItems, {name="SPKL2_FH_L VMON_CH4_THD+N", action=SpkMatch,match1="Channel 4:\n(.-)\nOK",match2="THD%+N:%s+(.-)%s",lower="NA",upper=-55})
table.insert(TestItems, {name="SPKL2_FH_L VMON_CH4_RMS (Root-Mean-Square)", action=SpkMatch,match1="Channel 4:\n(.-)\nOK",match2="RMS %(Root%-Mean%-Square%):%s+(.-)%s"})

table.insert(TestItems, {name="SPKL2_FH_L IMON_CH5_FFT Peak Magnitude", action=SpkMatch,match1="Channel 5:\n(.-)\nOK",match2="Peak Magnitude=(.-);"})
table.insert(TestItems, {name="SPKL2_FH_L IMON_CH5_Frequency", action=SpkMatch,match1="Channel 5:\n(.-)\nOK",match2="Frequency:%s+(.-)%s",lower=2350,upper=2450})
table.insert(TestItems, {name="SPKL2_FH_L IMON_CH5_SINAD", action=SpkMatch,match1="Channel 5:\n(.-)\nOK",match2="SINAD=(.-)%s",lower=15,upper="NA"})
table.insert(TestItems, {name="SPKL2_FH_L IMON_CH5_THD+N", action=SpkMatch,match1="Channel 5:\n(.-)\nOK",match2="THD%+N:%s+(.-)%s",lower="NA",upper=-47})
table.insert(TestItems, {name="SPKL2_FH_L IMON_CH5_RMS (Root-Mean-Square)", action=SpkMatch,match1="Channel 5:\n(.-)\nOK",match2="RMS %(Root%-Mean%-Square%):%s+(.-)%s"})


local function item24KSPKR2_CN_R(self)
  if iPadSerial == nil then
    ResultTable.resultCode = false
    return
  end  
  doScorpiusCmd("MIC3 OFF\n")
  doScorpiusCmd("mic4 on\n")
  doScorpiusCmd("MIC Wave Short\n")
  doDiagsCmd("audio --reset\n")
  doDiagsCmd("audioreg -b audmux -w -a 0x1C -d 0x000180909\n")
  doDiagsCmd("audioparam --set --block spkr2 --param enable-mon --value true\n")
  doDiagsCmd("audioparam --set --block spkr2 --param ch-vmon --value 6\n")
  doDiagsCmd("audioparam --set --block spkr2 --param ch-imon --value 7\n")
  doDiagsCmd("audioreg -b spkr2 -w -a 0x001A -d 0xCF\n")
  doDiagsCmd("audioreg -b spkr2 -w -a 0x001C -d 0x30\n")
  doDiagsCmd("audioreg -r -b spkr2 -a 0x001A -l 4\n")
  doDiagsCmd("routeaudio -b spkr2 -i spk-i2s -o spk-out -r\n")
  doDiagsCmd("processaudio --freebufs all\n")
  doDiagsCmd("audioparam -b socmca -p ap-mca2 -s -n master-lrclk-enable -v false\n")
  local rtSend = iPadSerial:send("loopaudio -b socmca --txport ap-mca2 --rxport ap-mca2 --bitdepth 32 --rate 48000 --len 1500 --freq 2400 -c8\n")
  local SendaLog = string.format("send[%s]:%s", (rtSend==0 and "Success" or "Fail"), rtSend or "cmd empty\n")
  local rtRecv = iPadSerial:recv({"Receiving"},1)
  local RecaLog = string.format("recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
  table.insert(ResultLog,SendaLog)
  table.insert(ResultLog,RecaLog)
  local rtSendLSPK1,rtRecvLSPKL1 = doScorpiusCmd("GetAudioF\n")
  rtRecv = iPadSerial:recv(":-) ",15)
  app.wait(1500)
  table.insert(ResultLog,"Wait 1500ms\n")
  doDiagsCmd("processaudio -p crop -i looprx0 -o \"--start 5000\"\n")
  _,ComTable["rtRecvf"] = doDiagsCmd("processaudio -p fft -i process0 -o \"--normalize false --peakBinWidth 3\"\n")
  _,ComTable["rtRecvt"] = doDiagsCmd("processaudio -p rms -i process0\n")
  
  rtRecv = string.match(rtRecvLSPKL1 or "","([%d%p]+)%s*Hz")
  local lowerlim,upperlim = self.lower,self.upper
  local bResult = compareAandB(rtRecv,lowerlim,upperlim,true)
  ResultTable.lowLimit = lowerlim
  ResultTable.UpLimit = upperlim
  ResultTable.resultCode = bResult
  ResultTable.resultString = rtRecv or "no data"
end
table.insert(TestItems, {name="2.4K Tone To SPKR2_FH_R", action=item24KSPKR2_CN_R,lower=2300, upper=2500})


table.insert(TestItems, {name="SPKR2_FH_R VMON_CH6_FFT Peak Magnitude", action=SpkMatch,match1="Channel 6:\n(.-)\nOK",match2="Peak Magnitude=(.-);"})
table.insert(TestItems, {name="SPKR2_FH_R VMON_CH6_Frequency", action=SpkMatch,match1="Channel 6:\n(.-)\nOK",match2="Frequency:%s+(.-)%s",lower=2350,upper=2450})
table.insert(TestItems, {name="SPKR2_FH_R VMON_CH6_SINAD", action=SpkMatch,match1="Channel 6:\n(.-)\nOK",match2="SINAD=(.-)%s",lower=15,upper="NA"})
table.insert(TestItems, {name="SPKR2_FH_R VMON_CH6_THD+N", action=SpkMatch,match1="Channel 6:\n(.-)\nOK",match2="THD%+N:%s+(.-)%s",lower="NA",upper=-55})
table.insert(TestItems, {name="SPKR2_FH_R VMON_CH6_RMS (Root-Mean-Square)", action=SpkMatch,match1="Channel 6:\n(.-)\nOK",match2="RMS %(Root%-Mean%-Square%):%s+(.-)%s"})

table.insert(TestItems, {name="SPKR2_FH_R IMON_CH7_FFT Peak Magnitude", action=SpkMatch,match1="Channel 7:\n(.-)\nOK",match2="Peak Magnitude=(.-);"})
table.insert(TestItems, {name="SPKR2_FH_R IMON_CH7_Frequency", action=SpkMatch,match1="Channel 7:\n(.-)\nOK",match2="Frequency:%s+(.-)%s",lower=2350,upper=2450})
table.insert(TestItems, {name="SPKR2_FH_R IMON_CH7_SINAD", action=SpkMatch,match1="Channel 7:\n(.-)\nOK",match2="SINAD=(.-)%s",lower=15,upper="NA"})
table.insert(TestItems, {name="SPKR2_FH_R IMON_CH7_THD+N", action=SpkMatch,match1="Channel 7:\n(.-)\nOK",match2="THD%+N:%s+(.-)%s",lower="NA",upper=-47})
table.insert(TestItems, {name="SPKR2_FH_R IMON_CH7_RMS (Root-Mean-Square)", action=SpkMatch,match1="Channel 7:\n(.-)\nOK",match2="RMS %(Root%-Mean%-Square%):%s+(.-)%s"})
--]]
--------------------Removed 20161107 by Kevin end----------------



--------------------Removed 20170105 by David Start----------------
function executeDiagsCmd(anCmd,endSign,timeout)
  if not iPadSerial then
    table.insert(g_ResultLog, "iPadSerial is Null!")
    return nil, nil
  end
  local _endSign = endSign or ":-) "
  local _timeout = timeout or 50
  local rtSend = iPadSerial:send(anCmd, 25) 
  local log = string.format("["..utils.timestamp().."]:".."send[%s]:%s", (rtSend==0 and "Success" or "Fail"), anCmd or "cmd empty\n")
  table.insert(g_ResultLog,log)
  local rtRecv = nil
  if rtSend == 0 then
    rtRecv = iPadSerial:recv(_endSign, _timeout)
    log = string.format("["..utils.timestamp().."]:".."recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
    table.insert(g_ResultLog,log)
    table.insert(g_ResultLog,"["..utils.timestamp().."]:".."[recv:finish]")
  end
  return rtSend, rtRecv
end

function doDiagsCmd(anCmd,endSign,timeout)
  local rtSend, rtRecv = executeDiagsCmd(anCmd,endSign,timeout)
  local errorLog = string.sub(rtRecv or "",-256)
  if string.match(errorLog or "","ommand%s+\'.-\'%s+not%s+found") then
    table.insert(g_ResultLog,"Send Diag Command Exception,try again.\n")
    rtSend, rtRecv = executeDiagsCmd(anCmd,endSign,timeout)
  end
  return rtSend, rtRecv
end
------------------------------------------------
function doDiagsCmd2(anCmd)
  if iPadSerial==nil then 
     table.insert(g_ResultLog, "iPadSerial is Null!")
    return nil, nil
  end
--  iPadSerial:lock()
  local rtSend = iPadSerial:send(anCmd, 15) 
  local Testlog = string.format("["..utils.timestamp().."]:".."send[%s]:%s", (rtSend==0 and "Success" or "Fail"), anCmd or "cmd empty\n")
  table.insert(g_ResultLog,Testlog)
  local rtRecv = nil
  if rtSend == 0 then
    rtRecv = iPadSerial:recv(":-) ",120)
    local Testlog = string.format("["..utils.timestamp().."]:".."recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
    table.insert(g_ResultLog,Testlog)
    table.insert(g_ResultLog,"["..utils.timestamp().."]:".."[recv:finish]")
  end
--  iPadSerial:unlock()
  return rtSend, rtRecv
end

------------------------------------------------
function doOrionCmd(OrionCmd,endCode,timeout)
  if OrionSerial==nil then 
     table.insert(g_ResultLog, "OrionSerial is Null!")
    return nil, nil
  end
  if endCode == nil then
    --endCode = {[[>]]}
    endCode = {[[>]],[[Ping\sHigh]]}
  end  
  timeout = timeout or 50
  OrionSerial:setRunTimeout(30)
--  OrionSerial:lock()
  
  local rtSend = OrionSerial:send(OrionCmd,25) 
  local aLog = string.format("["..utils.timestamp().."]:".."send[%s]:%s", (rtSend==0 and "Success" or "Fail"), OrionCmd or "cmd empty\n")
  table.insert(g_ResultLog,aLog)
  local rtRecv = nil
  if rtSend == 0 then
    rtRecv = OrionSerial:recv(endCode,timeout)  ---10
    aLog = string.format("["..utils.timestamp().."]:".."recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
    table.insert(g_ResultLog,aLog)
    table.insert(g_ResultLog,"["..utils.timestamp().."]:".."[recv:finish]")
  end
  
--  OrionSerial:unlock()
  return rtSend, rtRecv
end

------------------------------------------------
function doScorpiusCmd(FixtureCmd)
  if fixtureSerial==nil then 
    table.insert(g_ResultLog, "fixtureSerial is Null!")
    return nil, nil;
  end
  
  fixtureSerial:setRunTimeout(60)
--  fixtureSerial:lock()
  
  local rtSend = fixtureSerial:send(FixtureCmd,25) 
  local aLog = string.format("["..utils.timestamp().."]:".."send[%s]:%s", (rtSend==0 and "Success" or "Fail"), FixtureCmd or "cmd empty\n")
  table.insert(g_ResultLog,aLog)
  local rtRecv = nil
  if rtSend == 0 then
    rtRecv = fixtureSerial:recv({[[\*_\*\s?]]},50)
    local aLog = string.format("["..utils.timestamp().."]:".."recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
    table.insert(g_ResultLog,aLog)
    table.insert(g_ResultLog,"["..utils.timestamp().."]:".."[recv:finish]")
  end
  
--  fixtureSerial:unlock()
  return rtSend, rtRecv
end

------------------------------------------------
function doMikeyCmd(MikeyCmd)
  if mikeySerial==nil then 
    table.insert(g_ResultLog, "mikeySerial is Null!")
    return nil, nil;
  end
  
  mikeySerial:setRunTimeout(60)
--  fixtureSerial:lock()
  
  local rtSend = mikeySerial:send(MikeyCmd,30) 
  local aLog = string.format("["..utils.timestamp().."]:".."send[%s]:%s", (rtSend==0 and "Success" or "Fail"), FixtureCmd or "cmd empty\n")
  table.insert(g_ResultLog,aLog)
  local rtRecv = nil
  if rtSend == 0 then
    rtRecv = mikeySerial:recv({[[\*_\*\s?]]},30)
    local aLog = string.format("["..utils.timestamp().."]:".."recv[%s]:%s", (rtRecv and "Success" or "Fail"), rtRecv or "no data\n")
    table.insert(g_ResultLog,aLog)
    table.insert(g_ResultLog,"["..utils.timestamp().."]:".."[recv:finish]")
  end
  
--  fixtureSerial:unlock()
  return rtSend, rtRecv
end

--------------------Removed 20170105 by David end----------------

--------------------Removed 20170323 by David Start----------------
function itemBurnMatrix(self) 
  local strColor,hsColor,cgColor = nil,nil,nil
  local cmd, cmd1, cmd2, cmd3 = nil, nil, nil, nil
  local bResult,logResult = nil,"Pass";
  if not g_sfcStatus then
    bResult = false
    logResult = "SFC issue"
  else
    local hwconfig = g_tbSFCInfo["unit_lbl"]
    if hwconfig == nil or string.len(hwconfig) < 1 then 
      table.insert(g_ResultLog,"SFC : unit_lbl = nil")
      ResultTable.resultCode = false
      ResultTable.resultString = "SFC : unit_lbl = nil"
      return
    end
    for v1,v2,v3 in string.gmatch(hwconfig,"(.-)_(.-)_(.+)") do
      cmd1 = v1
      cmd2 = v2
      cmd3 = v3
      print(cmd1)
      print(cmd2)
      print(cmd3) 
    end 
    if (not cmd1) or (not cmd2) or (not cmd3) then
      ResultTable.resultCode = false
      ResultTable.resultString = "Can not get Special Label"
      return
    end
    cmd = cmd1 .. "/*/*/" .. cmd3 .. "/" .. cmd2
    cmd = "syscfg add CFG# " .. cmd .. "\n"
    local rtSend,rtRecv = doDiagsCmd(cmd)
    bResult = string.match(rtRecv or " ","Finish") and true or false
  end
  ResultTable.resultCode = bResult
  ResultTable.resultString = bResult and logResult or "Fail"
end

table.insert(TestItems, {name="Burn Matrix and Special builds", action=itemBurnMatrix})

--------------------Removed 20170323 by David End----------------

--------------------Removed 20170324 by David Start----------------
function getInfoFromUnitForSpecialBuilds(self)
  local bResult, logResult = nil, nil
  local rtSend,rtRecv = doDiagsCmd("syscfg print CFG#\n")
  _,_,logResult = string.find(rtRecv or "","syscfg print CFG#%s+(.+)%s+%[")

  if not logResult then
    ResultTable.resultCode = false
    ResultTable.resultString = "No data"
    return
  end  

  local _,_,buildEvent = string.find(logResult or "","(.-)%/")
  g_PDCAAttribute["BUILD_EVENT"] = buildEvent

  local _,_,matrixConfig = string.find(logResult or "",".+%/(.*)")
  g_PDCAAttribute["BUILD_MATRIX_CONFIG"] = matrixConfig

  local sBuild = buildEvent .. "_" .. matrixConfig
  g_PDCAAttribute["S_BUILD"] = sBuild

  local _,_,unitAttribute = string.find(logResult or "",".-%/(%d*)%/")
  g_PDCAAttribute["UNIT#"] = unitAttribute

  ResultTable.resultCode = true
  ResultTable.resultString = logResult
end  
table.insert(TestItems, {name="Read Back Matrix and Special Builds", action=getInfoFromUnitForSpecialBuilds})

--------------------Removed 20170324 by David End----------------

--------------------Removed 20170412 by David Start----------------
table.insert(TestItems, {name="iPad-1 CB Check", action=parseStrWithSpec})
TestItems[#TestItems].cmdSet = {"cbread 0x03 quiet\n"}
TestItems[#TestItems].specSet = {spec = "Passed"}

--------------------Removed 20170412 by David End----------------


--------------------------------------------------------------------------------------------
--[[
table.insert(TestItems, {name="Fixture offset upLeft 2", action = itemFixtureOffset})

table.insert(TestItems, {name="UpL2_Vrect@0.1C Initial set up (mV)", action = itemPhaseshifted,loopNumber = 50,lowerValue = 4.8,upperValue = 5.2})
table.insert(TestItems, {name="UpL2_VIrect_Fix_Get@0.1C (mA)", action = itemVrect_20mA,loopNumber = 50,lowerValue = 4.8,upperValue = 5.2})
table.insert(TestItems, {name="UpL2_VVrect_Fix_Get@0.1C (mV)", action = itemgetCurrent})
table.insert(TestItems, {name="UpL2_VRx_Loading_power@0.1C (W)", action = itemGetPower,lowerValue = 0.085,upperValue = 0.115})
table.insert(TestItems, {name="UpL2_VBridge_Phase@0.1C", action = itemBridgePhase})

table.insert(TestItems, {name="UpL2_VIrect_Fix_Get@1C (mA)", action = itemVrect_135mA,loopNumber = 50,lowerValue = 5.8,upperValue = 6.2})
table.insert(TestItems, {name="UpL2_VVrect_Fix_Get@1C (mV)", action = itemgetVoltage})
table.insert(TestItems, {name="UpL2_VRx_Loading_power@1C (W)", action = itemGetPower135ma,lowerValue = 0.255,upperValue = 0.345})
table.insert(TestItems, {name="UpL2_VBridge_Phase@1C", action = itemBridgePhase})

table.insert(TestItems, {name="UpL2_VIrect_Fix_Get@3C (mA)", action = itemVrect_135mA,loopNumber = 135,lowerValue = 5.8,upperValue = 6.2})
table.insert(TestItems, {name="UpL2_VVrect_Fix_Get@3C (mV)", action = itemgetVoltage})
table.insert(TestItems, {name="UpL2_VRx_Loading_power@3C (W)", action = itemGetPower135ma,lowerValue = 0.688,upperValue = 0.932})
table.insert(TestItems, {name="UpL2_VBridge_Phase@3C", action = itemBridgePhase})
table.insert(TestItems, {name="UpL2_VSys_I@3C", action = Sys_I_Vboost_OFF})
table.insert(TestItems, {name="UpL2_VSys_I_Delta_of_3C", action = Sys_I_Delta_of_3C})
table.insert(TestItems, {name="UpL2_VFOD_threshold@3C", action = itemFodfunction})

table.insert(TestItems, {name="UpL2_VIrect_Fix_Get@10C (mA)", action = itemVrect_135mA,loopNumber = 300,lowerValue = 9.8,upperValue = 10.2})
table.insert(TestItems, {name="UpL2_VVrect_Fix_Get@10C (mV)", action = itemgetVoltage})
table.insert(TestItems, {name="UpL2_VRx_Loading_power@10C (W)", action = itemGetPower135ma,lowerValue = 2.55,upperValue = 3.45})
table.insert(TestItems, {name="UpL2_VBridge_Phase@10C", action = itemBridgePhase})

table.insert(TestItems, {name="UpL2_VSys_I@10C", action = Sys_I_Vboost_OFF})
table.insert(TestItems, {name="UpL2_VSys_I_Delta_of_10C", action = Sys_I_Delta_of_10C})
--table.insert(TestItems, {name="UpL2_VVrect@Break_Point", action = pendingAdd})
--table.insert(TestItems, {name="UpL2_VRx_Current_Loading@Break_Point", action = pendingAdd})

--table.insert(TestItems, {name="UpL2_VBridge_Phase@Break_Point", action = pendingAdd})
table.insert(TestItems, {name="UpL2_VFOD_threshold@10C", action = itemFodfunction})
table.insert(TestItems, {name="UpL2_VTx_Temp@10C", action = itemTempFun})
--]]
-------------------------------------------------------------------------
--[[
table.insert(TestItems, {name="Fixture offset Down 2", action = itemFixtureOffset})

table.insert(TestItems, {name="Down2_Vrect@0.1C Initial set up (mV)", action = itemPhaseshifted,loopNumber = 50,lowerValue = 4.8,upperValue = 5.2})
table.insert(TestItems, {name="Down2_VIrect_Fix_Get@0.1C (mA)", action = itemVrect_20mA,loopNumber = 50,lowerValue = 4.8,upperValue = 5.2})
table.insert(TestItems, {name="Down2_VVrect_Fix_Get@0.1C (mV)", action = itemgetCurrent})
table.insert(TestItems, {name="Down2_VRx_Loading_power@0.1C (W)", action = itemGetPower,lowerValue = 0.085,upperValue = 0.115})
table.insert(TestItems, {name="Down2_VBridge_Phase@0.1C", action = itemBridgePhase})

table.insert(TestItems, {name="Down2_VIrect_Fix_Get@1C (mA)", action = itemVrect_135mA,loopNumber = 50,lowerValue = 5.8,upperValue = 6.2})
table.insert(TestItems, {name="Down2_VVrect_Fix_Get@1C (mV)", action = itemgetVoltage})
table.insert(TestItems, {name="Down2_VRx_Loading_power@1C (W)", action = itemGetPower135ma,lowerValue = 0.255,upperValue = 0.345})
table.insert(TestItems, {name="Down2_VBridge_Phase@1C", action = itemBridgePhase})

table.insert(TestItems, {name="Down2_VIrect_Fix_Get@3C (mA)", action = itemVrect_135mA,loopNumber = 135,lowerValue = 5.8,upperValue = 6.2})
table.insert(TestItems, {name="Down2_VVrect_Fix_Get@3C (mV)", action = itemgetVoltage})
table.insert(TestItems, {name="Down2_VRx_Loading_power@3C (W)", action = itemGetPower135ma,lowerValue = 0.688,upperValue = 0.932})
table.insert(TestItems, {name="Down2_VBridge_Phase@3C", action = itemBridgePhase})
table.insert(TestItems, {name="Down2_VSys_I@3C", action = Sys_I_Vboost_OFF})
table.insert(TestItems, {name="Down2_VSys_I_Delta_of_3C", action = Sys_I_Delta_of_3C})
table.insert(TestItems, {name="Down2_VFOD_threshold@3C", action = itemFodfunction})

table.insert(TestItems, {name="Down2_VIrect_Fix_Get@10C (mA)", action = itemVrect_135mA,loopNumber = 300,lowerValue = 9.8,upperValue = 10.2})
table.insert(TestItems, {name="Down2_VVrect_Fix_Get@10C (mV)", action = itemgetVoltage})
table.insert(TestItems, {name="Down2_VRx_Loading_power@10C (W)", action = itemGetPower135ma,lowerValue = 2.55,upperValue = 3.45})
table.insert(TestItems, {name="Down2_VBridge_Phase@10C", action = itemBridgePhase})

table.insert(TestItems, {name="Down2_VSys_I@10C", action = Sys_I_Vboost_OFF})
table.insert(TestItems, {name="Down2_VSys_I_Delta_of_10C", action = Sys_I_Delta_of_10C})
--table.insert(TestItems, {name="Down2_VVrect@Break_Point", action = pendingAdd})
--table.insert(TestItems, {name="Down2_VRx_Current_Loading@Break_Point", action = pendingAdd})

--table.insert(TestItems, {name="Down2_VBridge_Phase@Break_Point", action = pendingAdd})
table.insert(TestItems, {name="Down2_VFOD_threshold@10C", action = itemFodfunction})
table.insert(TestItems, {name="Down2_VTx_Temp@10C", action = itemTempFun})
--]]
------------------------------------------------------------------------------------------------
----table.insert(TestItems, {name="Tx Ping Vrect", action=itemTxPing})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----------------------------------------------------------------------------------------------
----table.insert(TestItems, {name="Fixture Vrect mode 1_mV", action=itemFixtureVrectMode1_mV})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----------------------------------------------------------------------------------------------
----table.insert(TestItems, {name="Wake Rx module up with Tx ping-nominal", action=itemWakeRxModuleUpWithTxPing_nominalPosition})
----TestItems[#TestItems].limitSet={lower = 1, upper = 1}
------------------------------------------------------------------------------------------------
----table.insert(TestItems, {name="Force 5.5V at Rectifier output (mV)-nominal", action=itemForce__5_5V__atRectifierOutput_nominalPosition})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
------------------------------------------------------------------------------------------------
----table.insert(TestItems, {name="Rx module read back power level (mV)-nominal", action=itemRequestRxModuleReadBackPowerLevel_nominalPosition})
----TestItems[#TestItems].limitSet={lower = 4500, upper = 6500}
------------------------------------------------------------------------------------------------
----table.insert(TestItems, {name="Fixture Vrect mode 2_mV", action=itemFixtureVrectMode2_mV})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
------------------------------------------------------------------------------------------------
----table.insert(TestItems, {name="Vary Rx loading (1C, 3C, 5C, 6C)-nominal", action=itemVaryRxLoading_1C_3C_5C_6C_nominalPosition})

----table.insert(TestItems, {name="Vary Rx loading_1C_current (mA)-nominal",       action=getValue, key="current40_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_1C_fixture Vrect (mV)-nominal", action=getValue, key="fixture_Vrect40_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_1C_TX Vrect (mV)-nominal",      action=getValue, key="TX_Vrect40_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_1C_power (W)-nominal",          action=getValue, key="power40_nominal"})
----TestItems[#TestItems].limitSet={lower = 0.1, upper = 0.4}

----table.insert(TestItems, {name="Vary Rx loading_3C_current (mA)-nominal",       action=getValue, key="current120_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_3C_fixture Vrect (mV)-nominal", action=getValue, key="fixture_Vrect120_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_3C_TX Vrect (mV)-nominal",      action=getValue, key="TX_Vrect120_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_3C_power (W)-nominal",          action=getValue, key="power120_nominal"})
----TestItems[#TestItems].limitSet={lower = 0.4, upper = 0.8}

----table.insert(TestItems, {name="Vary Rx loading_5C_current (mA)-nominal",       action=getValue, key="current200_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_5C_fixture Vrect (mV)-nominal", action=getValue, key="fixture_Vrect200_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_5C_TX Vrect (mV)-nominal",      action=getValue, key="TX_Vrect200_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_5C_power (W)-nominal",          action=getValue, key="power200_nominal"})
----TestItems[#TestItems].limitSet={lower = 0.8, upper = 1.2}

----table.insert(TestItems, {name="Vary Rx loading_6C_current (mA)-nominal",       action=getValue, key="current240_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_6C_fixture Vrect (mV)-nominal", action=getValue, key="fixture_Vrect240_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_6C_TX Vrect (mV)-nominal",      action=getValue, key="TX_Vrect240_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----table.insert(TestItems, {name="Vary Rx loading_6C_power (W)-nominal",          action=getValue, key="power240_nominal"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}

----table.insert(TestItems, {name="Current at Vrect under 5V", action=getValue, key="Current at Vrect under 5V"})
----TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----[[
----------------------------------------------------------------------------------------------
--table.insert(TestItems, {name="Check scorpius 2mm offset ", action=itemScorpiusCheck_2mmOffset})
----------------------------------------------------------------------------------------------
--table.insert(TestItems, {name="Wake Rx module up with Tx ping-2mm offset", action=itemWakeRxModuleUpWithTxPing_2mmOffset})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----------------------------------------------------------------------------------------------
--table.insert(TestItems, {name="Force 5.5V at Rectifier output (mV)-2mm offset", action=itemForce__5_5V__atRectifierOutputUnder_2mmOffset})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----------------------------------------------------------------------------------------------
--table.insert(TestItems, {name="Rx module read back power level (mV)-2mm offset", action=itemRequestRxmoduleReadBackPowerLevel_2mmOffset})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----------------------------------------------------------------------------------------------
--table.insert(TestItems, {name="Fixture Vrect mode 2_mV_2mm offset", action=itemFixtureVrectMode2_mV_2mmOffset})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----------------------------------------------------------------------------------------------
--table.insert(TestItems, {name="Vary Rx loading (1C, 3C, 5C, 6C)-2mm offset", action=itemVaryRxLoading_1C_3C_5C_6C_2mmOffset})

--table.insert(TestItems, {name="Vary Rx loading_1C_current (mA)-2mm offset",       action=getValue, key="current40_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_1C_fixture Vrect (mV)-2mm offset", action=getValue, key="fixture_Vrect40_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_1C_TX Vrect (mV)-2mm offset",      action=getValue, key="TX_Vrect40_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_1C_power (W)-2mm offset",          action=getValue, key="power40_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}

--table.insert(TestItems, {name="Vary Rx loading_3C_current (mA)-2mm offset",       action=getValue, key="current120_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_3C_fixture Vrect (mV)-2mm offset", action=getValue, key="fixture_Vrect120_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_3C_TX Vrect (mV)-2mm offset",      action=getValue, key="TX_Vrect120_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_3C_power (W)-2mm offset",          action=getValue, key="power120_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}

--table.insert(TestItems, {name="Vary Rx loading_5C_current (mA)-2mm offset",       action=getValue, key="current200_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_5C_fixture Vrect (mV)-2mm offset", action=getValue, key="fixture_Vrect200_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_5C_TX Vrect (mV)-2mm offset",      action=getValue, key="TX_Vrect200_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_5C_power (W)-2mm offset",          action=getValue, key="power200_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}

--table.insert(TestItems, {name="Vary Rx loading_6C_current (mA)-2mm offset",       action=getValue, key="current240_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_6C_fixture Vrect (mV)-2mm offset", action=getValue, key="fixture_Vrect240_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_6C_TX Vrect (mV)-2mm offset",      action=getValue, key="TX_Vrect240_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
--table.insert(TestItems, {name="Vary Rx loading_6C_power (W)-2mm offset",          action=getValue, key="power240_2mmOffset"})
--TestItems[#TestItems].limitSet={lower = "NA", upper = "NA"}
----]]


--table.insert(TestItems, {name="PPVBUS_Boosted Scorpius short test", action=itemScorpiusshorttest,line="1"})
--table.insert(TestItems, {name="PP1V8_S2_SCORPIUS Scorpius short test", action=itemScorpiusshorttest,line="2"})
--table.insert(TestItems, {name="PP3V3_LDO Scorpius short test", action=itemScorpiusshorttest,line="3"})
--table.insert(TestItems, {name="PP5V0_CHRG_PUMP Scorpius short test", action=itemScorpiusshorttest,line="4"})


--table.insert(TestItems, {name="LPP Test", action=pendingAdd})
--table.insert(TestItems, {name="Rx ASK preset message", action=pendingAdd})
--table.insert(TestItems, {name="Check Jupiter FW Version", action=pendingAdd})
--table.insert(TestItems, {name="==================================", action=pendingAdd})

------------------add 10.11 by Elaine---------------
------delete 10.12 by Elaine
--function Sys_I_Delta_of_Vboost_ONAndOff(self)
--  if ComTable["VboostOn"] and ComTable["VboostOff"] then
--    local testResult = (ComTable["VboostOn"] - ComTable["VboostOff"])/1000.0
--    local bResult = testResult and true or false
--    ResultTable.resultCode = bResult
--    ResultTable.resultString = testResult
--  else
--    ResultTable.resultCode = false
--    ResultTable.resultString = "No Data"
--  end

--end

--function Sys_I_Delta_of_3C(self)

--  if ComTable["VboostOff"] and ComTable["Sys_I@3C"] then
--    local testResult = (ComTable["Sys_I@3C"] - ComTable["VboostOff"])/1000.0
--    local bResult = testResult and true or false
--    ResultTable.resultCode = bResult
--    ResultTable.resultString = testResult
--  else
--    ResultTable.resultCode = false
--    ResultTable.resultString = "No Data"
--  end
--end

--function Sys_I_Delta_of_10C(self)
--  if ComTable["VboostOff"] and ComTable["Sys_I@10C"] then
--    local testResult = (ComTable["Sys_I@10C"] - ComTable["VboostOff"])/1000.0
--    local bResult = testResult and true or false
--    ResultTable.resultCode = bResult
--    ResultTable.resultString = testResult
--  else
--    ResultTable.resultCode = false
--    ResultTable.resultString = "No Data"
--  end
--end

--[[
function itemScorpiusCheck_2mmOffset(self)
  local rtSend0, rtRecv0 = doScorpiusCmd("left 2\r")
  local rtSend1, rtRecv1 = doScorpiusCmd("up 2\r")

  if rtSend0 and rtSend1 then
    g_scopriusFlag = true
  end
  local bResult = true
  if not (string.match(rtRecv0 or "", "Pass") and string.match(rtRecv1 or "", "Pass")) then
    bResult = false
  end
  ResultTable.resultCode = bResult
end  
--]]