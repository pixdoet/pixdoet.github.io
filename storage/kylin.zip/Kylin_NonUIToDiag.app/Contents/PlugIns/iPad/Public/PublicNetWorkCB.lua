----------------------------------------------------------------------------------
pcall(require("KylinNetworkCB"))

-----------------------------NetWork CB: Check Fatal Error-------------------------
function NetWorkCBCFE(self)
  local bFinalResult = g_finalResult
  local bRt, loginfo, tbClearIndex = getClearNetworkCBIndex(sn, bFinalResult)
  table.insert(g_ResultLog, loginfo)
  if not tbClearIndex then
    ResultTable.resultCode = bRt;
    ResultTable.resultString = loginfo or "Fail";
    return;
  end

  ---------------------------------------
  for i=1, #tbClearIndex do
    local stationCBIndex = string.format("0x%02x", tbClearIndex[i])
    local diagCmd = "cbwrite " .. stationCBIndex .. " incomplete\n"
    local rtSend,rtRecv = doDiagsCmd(diagCmd)
    if not rtSend then
      bRt = false
      break 
    end 
  end 
  ResultTable.resultCode = bRt;
end

-----------------------------NetWork CB: Check Previous Station CBs------------------
function NetWorkCBCPSC(self)
  local stationIndex = self.stationIndex;
  local rtSend, rtRecvStr = doDiagsCmd("cbreadall\n")
  local currentTime = os.date("!%Y%m%d%H%M%S")
  doDiagsCmd("rtc --set " .. currentTime .. "\n")
  doDiagsCmd("cbwrite " .. stationIndex .. " incomplete\n");

  ---------------------------------------
  if rtRecvStr == nil then
    table.insert(g_ResultLog, "fail to get dut all CB status")
    ResultTable.resultCode = false
    return;
  end

  ---------------------------------------
  local tbAllStationsCB = {}
  local regular = "(0x%x+)%s+(.-)%s+(.-)%s+(.-)%s+(.-)%s+(.-)%s(.-)[\t\r\n%s]"
  for d1,d2,d3,d4,d5,d6,d7 in string.gmatch(rtRecvStr, regular) do
    tbAllStationsCB[tonumber(d1)] = {state=d2,relativeFailCount=d3,absoluteFailCount=d4,eraseCount=d5,lastTested=d6,testSWversion=d7}
  end

  for key,value in pairs(tbAllStationsCB) do 
    print(key);
    for key1,value1 in pairs(value) do
      print(tostring(key1) .. " : " .. tostring(value1));
    end 
  end 

  ---------------------------------------
  local bRt, loginfo = checkNetworkCB(sn, tbAllStationsCB, stationIndex);
  table.insert(g_ResultLog, loginfo);
  
  ResultTable.resultCode = bRt;
  ResultTable.resultString = loginfo;
end

----------------------------------------------------------------------------------





