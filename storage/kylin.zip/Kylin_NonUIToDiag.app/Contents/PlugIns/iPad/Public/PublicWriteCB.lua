----------------------------------------------------------------------------------
pcall(require("KylinWriteCB"))
pcall(require("KylinNetworkCB"))
----------------------------------------------------------------------------------
function itemWriteCB(self)
  
  local bFinalResult = g_finalResult
  local stationPassCode = self.passCode
  local bRt, hashCode, loginfo = nil
  local bResult, logResult = nil
  local stationIndex = string.format("0x%X",self.stationIndex)--self.stationIndex
  if iPadSerial == nil then
    table.insert(g_ResultLog,"iPadSerial is nil")
    ResultTable.resultCode = false
    ResultTable.resultString = "iPadSerial is nil"
    return
  end
 
  ---------------------------------------
  if not bFinalResult then
    local diagCmd = "cbwrite " .. tostring(stationIndex) .. " fail\n";
    local rtSend,rtRecv = doDiagsCmd(diagCmd)
    if rtRecv==nil then
      bResult = false;
      logResult = "Receive data is nil";
    else
      bResult = string.match(rtRecv or " ",self.set[1]) and true or false;
      logResult = bResult and "Pass" or "Fail";
    end
    ResultTable.resultCode = bResult;
    ResultTable.resultString = logResult;
    return
  end
  ---------------------------------------
  
  local rtSendTest,rtRecvGetNonce = doDiagsCmd("getnonce\n");
  if stationPassCode then
    bRt, hashCode, loginfo = getStationHashCodeByCBA(stationPassCode, rtRecvGetNonce);
  else
    bRt, hashCode, loginfo = getStationHashCodeBySCB(self.stationIndex, rtRecvGetNonce);
  end  
  if not bRt then
    ResultTable.resultCode = bRt;
    ResultTable.resultString = "get hash code fail";
    return;
  end
  
  ---------------------------------------
  local diagCmd = "cbwrite " .. tostring(stationIndex) .. " pass\n";
  local rtSend = sendDiagsCmd(diagCmd, 20) 
  local rtRecv = nil
  if rtSend == 0 then
    rtRecv = receiveDiagsCmd(">", 50)
    if not rtRecv then
      ResultTable.resultCode = false;
      ResultTable.resultString = "write pass to dut fail";
      return;  
    end
  end  
   
    ---------------------------------------
    rtSend,rtRecv = doDiagsCmd(hashCode)
    if not rtRecv then
      ResultTable.resultCode = false;
      ResultTable.resultString = "write hashCode to dut fail";
      return;  
    end
    if string.match(rtRecv or " ",self.set[1]) then
      ResultTable.resultCode = true;
      ResultTable.resultString = "Pass";
    else
      ResultTable.resultCode = false;
      ResultTable.resultString = "Fail";    
    end
    return
  end





