-----------------------------------SFC Module-----------------------------------
print("load and do SCB script...");

--------------------------------------------------------------------------------
local bSCBStatus, scb = pcall(require, "scb");
if bSCBStatus and scb then
  print("require scb library success!");
else
  print("require scb library fail:", scb);
  return;
end

-----------------------------------Private Function ----------------------------
local g_SCBLogInfo = {}
local function IPTrace(anInfo)
  print(anInfo);
  table.insert(g_SCBLogInfo, anInfo);
end

----------------------------------------------------------------------------------
function getStationHashCodeBySCB(stationIndex, rtRecvGetNonce)
  g_SCBLogInfo = {}
  local nRt = -1
  local hashCode = nil
  local bRt = false
  if (not stationIndex) or (not rtRecvGetNonce) then
    local parameter = tostring(stationIndex) .. " " .. tostring(rtRecvGetNonce);
    IPTrace("parameter is invalid: " .. parameter);
    return bRt, hashCode, table.concat(g_SCBLogInfo, "\n");
  end
  if string.len(tostring(rtRecvGetNonce)) < 30 then
    IPTrace("get nonce return error");
    return bRt, hashCode, table.concat(g_SCBLogInfo, "\n");
  end

  ---------------------------------------
  local rtRecvNonce = string.sub(rtRecvGetNonce,11,30)
  nRt,hashCode = scb.get_station_hash(stationIndex, rtRecvNonce)
  if nRt == 0 then
    IPTrace("STATUS_OK");
    bRt = true
  elseif nRt == -10001 then
    IPTrace("ERROR_CREATE_SHA1DIGEST")
  elseif nRt == -10002 then
    IPTrace("ERROR_UNKNOWN_STATION_ID")
  end
  return bRt, hashCode, table.concat(g_SCBLogInfo, "\n");
end
----------------------------------------------------------------------------------  





