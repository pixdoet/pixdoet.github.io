-----------------------------------SFC Module-----------------------------------
print("load and do SFC script...");

local bStatus, ip = pcall(require, "KylinSkunk");
if bStatus and ip then
  print("require KylinSkunk success!");
else
  print("require KylinSkunk fail:", ip);
  return;
end

--------------------------------------------------------------------------------
local bSFCStatus, sfc = pcall(require, "sfc");
if bSFCStatus and sfc then
  print("require sfc library success!");
else
  print("require sfc library fail:", sfc);
  return;
end

-----------------------------------Private Function ----------------------------
local g_SFCLogInfo = {}
local function IPTrace(anInfo)
  print(anInfo);
  table.insert(g_SFCLogInfo, anInfo);
end

local function isNull(anObject)
  return (anObject==nil) or (tostring(anObject)=="userdata: 0x0");
end

local function isSuccess(reply)
  if isNull(reply) then
    IPTrace("Error: reply is NULL");
    return false;
  end
  local bRt = ip.success(reply);
  if not bRt then
    local errorInfo = ip.reply_getError(reply);
    IPTrace("Error:" .. tostring(errorInfo));
  end
  ip.reply_destroy(reply);

  return (bRt==true);
end

local function cancelUUTHandle(UUTHandle)
  if isNull(UUTHandle) then
    IPTrace("Error: UUTHandle is NULL");
    return false;
  end
  local reply = ip.UUTCancel(UUTHandle);
  local bRt = isSuccess(reply);
  if not bRt then
    IPTrace("Error: UUTCancel fail!");
  end

  return (bRt==true);
end

local function freeUUTHandle(UUTHandle)
  if not isNull(UUTHandle) then
    cancelUUTHandle(UUTHandle);
    ip.UID_destroy(UUTHandle);
  end
end

----------------------------------------------------------------------------------
function querySFCRecord(dutSn, tbQueryKeys)
  g_SFCLogInfo = {}
  local nRt, tbSFCQueryRecord = nil
  if (not dutSn) or (not tbQueryKeys) then
    local parameter = tostring(dutSn) .. " " .. tostring(tbQueryKeys);
    IPTrace("parameter is invalid: " .. parameter);
    return false, tbSFCQueryRecord, table.concat(g_SFCLogInfo, "\n");
  end

  ---------------------------------------
  local reply, UUTHandle = ip.UUTStart();
  local bRt = isSuccess(reply);
  if not bRt then
    IPTrace("UUTStart fail");
    freeUUTHandle(UUTHandle);
    return false, tbSFCQueryRecord, table.concat(g_SFCLogInfo, "\n");
  end

  local ipReply,stationName,ilength = ip.getGHStationInfo(UUTHandle,IP_ENUM_GHSTATIONINFO.IP_STATION_TYPE)
  bRt = isSuccess(ipReply);
  if not bRt then 
    IPTrace("get GH station name fail:" .. tostring(stationName));
    return false, tbSFCQueryRecord, table.concat(g_SFCLogInfo, "\n");
  end
  freeUUTHandle(UUTHandle);

  ---------------------------------------
  nRt, tbSFCQueryRecord = sfc.SFCQueryRecordByStationName(dutSn,stationName,tbQueryKeys)
  if nRt < 0 then
    IPTrace("SFC query record fail" .. tostring(nRt));
    return false, tbSFCQueryRecord, table.concat(g_SFCLogInfo, "\n");
  end
  IPTrace("SFC query record OK" .. tostring(nRt));
  return true, tbSFCQueryRecord, table.concat(g_SFCLogInfo, "\n");
end

----------------------------------------------------------------------------------  
function querySFCStatus()
  g_SFCLogInfo = {}
  local reply, UUTHandle = ip.UUTStart();
  local bRt = isSuccess(reply);
  if not bRt then
    IPTrace("UUTStart fail");
    freeUUTHandle(UUTHandle);
    return false, tbSFCQueryRecord, table.concat(g_SFCLogInfo, "\n");
  end
  
  ---------------------------------------
  local ipReply,sfcQueryUnitStatus,ilength = ip.getGHStationInfo(UUTHandle,IP_ENUM_GHSTATIONINFO.IP_SFC_QUERY_UNIT_ON_OFF)
  bRt = isSuccess(ipReply);
  if not bRt then 
    IPTrace("get sfc query unit status fail:" .. tostring(sfcQueryUnitStatus));
    return false, sfcQueryUnitStatus, table.concat(g_SFCLogInfo, "\n");
  end
  freeUUTHandle(UUTHandle);
  IPTrace("get sfc query unit status pass:");
  return true, sfcQueryUnitStatus, table.concat(g_SFCLogInfo, "\n");
end  
----------------------------------------------------------------------------------
function querySFCRecordByURL(queryString)
  g_SFCLogInfo = {}
  local nRt, strSFCQueryRecord = nil
  if not queryString then
    local parameter = tostring(queryString);
    IPTrace("parameter is invalid: " .. parameter);
    return false, strSFCQueryRecord, table.concat(g_SFCLogInfo, "\n");
  end

  ---------------------------------------
  strSFCQueryRecord = sfc.WSRequest(queryString)--NetRequest --> WSRequest
  if not strSFCQueryRecord or strSFCQueryRecord == "" or string.len(strSFCQueryRecord)<0 or not (string.match(strSFCQueryRecord or "", "0 SFC_OK")) then
    IPTrace("SFC query record fail" .. tostring(strSFCQueryRecord));
    return false, strSFCQueryRecord, table.concat(g_SFCLogInfo, "\n");
  end
  IPTrace("SFC query record OK" .. tostring(strSFCQueryRecord));
  return true, strSFCQueryRecord, table.concat(g_SFCLogInfo, "\n");
end  

----------------------------------------------------------------------------------







