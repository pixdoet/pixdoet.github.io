-----------------------------------PDCA Module-----------------------------------
print("load and do PDCA script...");

local bStatus, ip = pcall(require, "KylinSkunk");
if bStatus and ip then
    print("require KylinSkunk success!");
else
    print("require KylinSkunk fail:", ip);
    return;
end

-----------------------------------Private Function ----------------------------
local g_PDCALogInfo = {}
local function IPTrace(anInfo)
    print(anInfo);
    table.insert(g_PDCALogInfo, anInfo);
end

local function isNull(anObject)
    return (anObject==nil) or (tostring(anObject)=="userdata: 0x0");
end

local function isSuccess(reply)
    if isNull(reply) then
        IPTrace("Error: reply is NULL");
        return false;
    end
    local bRt = ip.success(reply);
    if not bRt then
        local errorInfo = ip.reply_getError(reply);
        IPTrace("Error:" .. tostring(errorInfo));
    end
    ip.reply_destroy(reply);

    return (bRt==true);
end

local function amIOkay(UUTHandle, dutSn)
    if isNull(UUTHandle) then
        IPTrace("Error: UUTHandle is NULL");
        return false;
    end
    local reply = ip.amIOkay(UUTHandle, dutSn);
    local bRt = isSuccess(reply);
    if not bRt then
        IPTrace("Error: amIOkay fail");
    end

    return (bRt==true);
end

local function cancelUUTHandle(UUTHandle)
    if isNull(UUTHandle) then
        IPTrace("Error: UUTHandle is NULL");
        return false;
    end
    local reply = ip.UUTCancel(UUTHandle);
    local bRt = isSuccess(reply);
    if not bRt then
        IPTrace("Error: UUTCancel fail!");
    end

    return (bRt==true);
end

local function freeUUTHandle(UUTHandle)
    if not isNull(UUTHandle) then
        cancelUUTHandle(UUTHandle);
        ip.UID_destroy(UUTHandle);
    end
end

----------------------------------------------------------------------------------
local function freeSpecAndResult(testSpec, testResult)
    if not isNull(testSpec) then
        ip.testSpec_destroy(testSpec)
    end
    if not isNull(testResult) then
        ip.testResult_destroy(testResult);
    end    
end

local function validateResultValue(aResult)
    if aResult==false then aResult = IP_PASSFAILRESULT.IP_FAIL; end
    if aResult==true then aResult = IP_PASSFAILRESULT.IP_PASS; end
    aResult = tonumber(aResult);
    if (aResult==nil) or (aResult<IP_PASSFAILRESULT.IP_FAIL or aResult>IP_PASSFAILRESULT.IP_NA) then
        IPTrace("Error: result value is invalid: " .. tostring(aResult));
        return nil;
    end

    return aResult;
end

----------------------------------------------------------------------------------
local function createTestSpec(tbTestSpec)
    local testSpec = ip.testSpec_create();
    if isNull(testSpec) then 
        IPTrace("Error: testSpec_create fail");
        return false, nil;
    end

    local bFinalRt = true;
    local v = tbTestSpec;

    --------------------------------------------
    local bRt = v.testName and ip.testSpec_setTestName(testSpec, v.testName, v.testName:len());
    if not bRt then
        IPTrace("Error from setTestName: ");
        IPTrace("testName:" .. tostring(v.testName) .. " type:" .. type(v.testName));
        bFinalRt = false;
    end

    if v.subTestName and v.subTestName ~= "" then
        bRt = ip.testSpec_setSubTestName(testSpec, v.subTestName, v.subTestName:len());
        if not bRt then
            IPTrace("Error from setSubTestName: ");
            IPTrace("subTestName:" .. tostring(v.subTestName) .. " type:" .. type(v.subTestName));
            bFinalRt = false;
        end
    end

    if v.subSubTestName and v.subSubTestName ~= "" then
        bRt = ip.testSpec_setSubSubTestName(testSpec, v.subSubTestName, v.subSubTestName:len());
        if not bRt then
            IPTrace("Error from setSubSubTestName: ");
            IPTrace("subSubTestName:" .. tostring(v.subSubTestName) .. " type:" .. type(v.subSubTestName));
            bFinalRt = false;
        end
    end

    --------------------------------------------
    if v.lower and v.upper then
        v.lower = tostring(v.lower);
        v.upper = tostring(v.upper);
        bRt = ip.testSpec_setLimits(testSpec, v.lower, v.lower:len(), v.upper, v.upper:len());
        if not bRt then
            IPTrace("Error from setLimits: ");
            IPTrace("lower:" .. tostring(v.lower) .. " type:" .. type(v.lower));
            IPTrace("upper:" .. tostring(v.upper) .. " type:" .. type(v.upper));
            bFinalRt = false;
        end
    end

    --------------------------------------------
    if v.units then
        bRt = ip.testSpec_setUnits(testSpec, v.units, v.units:len());
        if not bRt then
            IPTrace("Error from setUnits: ");
            IPTrace("units:" .. tostring(v.units) .. " type:" .. type(v.units));
            bFinalRt = false;
        end
    end

    --------------------------------------------
    v.priority = (v.priority or 0);
    bRt = ip.testSpec_setPriority(testSpec, v.priority);
    if not bRt then
        IPTrace("Error from setPriority: ");
        IPTrace("priority:" .. tostring(v.priority) .. " type:" .. type(v.priority));
        bFinalRt = false;
    end

    return bFinalRt, testSpec;
end

----------------------------------------------------------------------------------
local function createTestResult(tbTestResult)
    local testResult = ip.testResult_create();
    if isNull(testResult) then
        IPTrace("Error: testResult_create fail");
        return false, nil;
    end

    local bFinalRt = true;
    local v = tbTestResult;

    --------------------------------------------
    v.result = validateResultValue(v.result)
    local bRt = (v.result ~= nil);
    if bRt then
        bRt = ip.testResult_setResult(testResult, v.result);
        if not bRt then
            IPTrace("Error from setResult: ");
            IPTrace("result:" .. tostring(v.result) .. " type:" .. type(v.result));
            bFinalRt = false;
        end
    else
        IPTrace("Error: result is an invalid value: ");
        IPTrace("result:" .. tostring(v.result) .. " type:" .. type(v.result));
        bFinalRt = false;
    end

    --------------------------------------------
    if v.value then
        bRt = ip.testResult_setValue(testResult, v.value, v.value:len());
        if not bRt then
            IPTrace("Error from setValue: ");
            IPTrace("value:" .. tostring(v.value) .. " type:" .. type(v.value));
            bFinalRt = false;
        end
    end

    --------------------------------------------
    if v.message then 
        bRt = ip.testResult_setMessage(testResult, v.message, v.message:len());
        if not bRt then
            IPTrace("Error from setMessage: ");
            IPTrace("message:" .. tostring(v.message) .. " type:" .. type(v.message));
            bFinalRt = false;
        end
    elseif v.result==IP_PASSFAILRESULT.IP_FAIL then
        IPTrace("Error: result is fial but message is nil");
        bFinalRt = false;
    end

    return bFinalRt, testResult;
end

----------------------------------------------------------------------------------
local function addResult(UUTHandle, tbResultArray)
    if isNull(UUTHandle) or (tbResultArray==nil) then
        IPTrace("Error: UUTHandle is NULL or tbResultArray is nil");
        return false;
    end

    local bFinalRt = nil;
    for i, v in ipairs(tbResultArray) do
        local bTestSpec, hTestSpec = createTestSpec(v);
        local bTestResult, hTestResult = createTestResult(v);
        local bRt = (bTestSpec and bTestResult);
        if bRt then
            local reply = ip.addResult(UUTHandle, hTestSpec, hTestResult);
            bRt = isSuccess(reply);
            if not bRt then 
                IPTrace("Error from addResult at index:" .. tostring(i));
            end
        else
            IPTrace("Error from createt testSpe or testResult at index:" .. tostring(i));
        end
        bFinalRt = (bFinalRt~=false and bRt);
        freeSpecAndResult(hTestSpec, hTestResult);
    end

    return (bFinalRt==true);
end

----------------------------------------------------------------------------------
local function addAttribute(UUTHandle, tbAttribute)
    if isNull(UUTHandle) or (tbAttribute==nil) then
        IPTrace("Error: UUTHandle is NULL or tbAttribute is nil");
        return false;
    end
    local bFinalRt = nil;
    for key, value in pairs(tbAttribute) do
        local reply = ip.addAttribute(UUTHandle, key, value);
        local bRt = isSuccess(reply);
        if not bRt then 
            IPTrace("Error from addAttribute:");
            IPTrace("key:" .. tostring(key) .. " type:" .. type(key));
            IPTrace("value:" .. tostring(value) .. " type:" .. type(value));
        end
        bFinalRt = (bFinalRt~=false and bRt);
    end

    return (bFinalRt==true);
end

----------------------------------------------------------------------------------
local function addBlobFile(UUTHandle, tbBlobFile)
    if isNull(UUTHandle) or (tbBlobFile==nil) then
        IPTrace("Error: UUTHandle is NULL or tbBlobFile is nil");
        return false;
    end
    local bFinalRt = nil;
    for key, value in pairs(tbBlobFile) do
        local reply = ip.addBlob(UUTHandle, key, value);
        local bRt = isSuccess(reply);
        if not bRt then 
            IPTrace("Error from addBlob:");
            IPTrace("key:" .. tostring(key) .. " type:" .. type(key));
            IPTrace("value:" .. tostring(value) .. " type:" .. type(value));
        end
        bFinalRt = (bFinalRt~=false and bRt);
    end

    return (bFinalRt==true);
end

-------------------------------------Interface---------------------------------------------
function uploadPDCA(tbAttribute, tbBlobFile, tbResultArray, nFinalResult)
    g_PDCALogInfo = {};
    local dutSn = tbAttribute and tbAttribute[IPTable.IP_ATTRIBUTE_SERIALNUMBER];
    if not dutSn then
        IPTrace("dutSn is empty");
        return false, table.concat(g_PDCALogInfo, "\n");
    end

    nFinalResult = validateResultValue(nFinalResult)
    if (nFinalResult==nil) then
        return false, table.concat(g_PDCALogInfo, "\n");
    end

    ----------------------------------------------------------------
    local reply, UUTHandle = ip.UUTStart();
    local bRt = isSuccess(reply);
    if not bRt then
        IPTrace("UUTStart fail");
        freeUUTHandle(UUTHandle);
        return false, table.concat(g_PDCALogInfo, "\n");
    end

    reply = ip.setStartTime(UUTHandle, os.time());
    bRt = isSuccess(reply);
    if not bRt then
        IPTrace("setStartTime fail");
        freeUUTHandle(UUTHandle);
        return false, table.concat(g_PDCALogInfo, "\n");
    end

    ----------------------------------------------------------------
    reply = ip.validateSerialNumber(UUTHandle, dutSn);
    bRt = isSuccess(reply);
    if not bRt then
        IPTrace("dutSn invalid:" .. dutSn);
        freeUUTHandle(UUTHandle);
        return false, table.concat(g_PDCALogInfo, "\n");
    end

    ---------------
    bRt = amIOkay(UUTHandle, dutSn);
--    if not bRt then
--        IPTrace("amIOkay query fail!");
--        freeUUTHandle(UUTHandle);
--        return false, table.concat(g_PDCALogInfo, "\n");
--    end

    ----------------------------------------------------------------
    local bFinalRt = true;
    bRt = addAttribute(UUTHandle, tbAttribute);
    if not bRt then
        IPTrace("addAttribute fail");
        bFinalRt = false;
    end

    ---------------
    if tbBlobFile then 
        bRt = addBlobFile(UUTHandle, tbBlobFile);
        if not bRt then
            IPTrace("addBlobFile fail");
            bFinalRt = false;
        end
    end

    ---------------
    if tbResultArray then 
        bRt = addResult(UUTHandle, tbResultArray);
        if not bRt then
            IPTrace("addResult fail");
            bFinalRt = false;
        end
    end

    ----------------------------------------------------------------
--    if (not bFinalRt) or (not amIOkay(UUTHandle, dutSn)) then
--        IPTrace("bFinalRt fail or amIOKoy fail");
--        freeUUTHandle(UUTHandle);
--        return false, table.concat(g_PDCALogInfo, "\n");
--    end

    ----------------------------------------------------------------
    reply = ip.UUTDone(UUTHandle)
    bRt = isSuccess(reply);
--    if not bRt then
--        IPTrace("UUTDone fail")
--        freeUUTHandle(UUTHandle);
--        return false, table.concat(g_PDCALogInfo, "\n"); 
--    end

    reply = ip.setStopTime(UUTHandle, os.time());
    bRt = isSuccess(reply);
    if not bRt then
        IPTrace("setStopTime fail");
        freeUUTHandle(UUTHandle);
        return false, table.concat(g_PDCALogInfo, "\n");
    end

    ----------------------------------------------------------------
    reply = ip.UUTCommit(UUTHandle, nFinalResult);
    bRt = isSuccess(reply);
    if not bRt then
        IPTrace("UUTCommit fail!");
        freeUUTHandle(UUTHandle);
        return false, table.concat(g_PDCALogInfo, "\n");
    else
        IPTrace("uploadPDCA Success!");
    end
    ip.UID_destroy(UUTHandle);

    return bRt, table.concat(g_PDCALogInfo, "\n");
end

----------------------------------------------------------------------------------
g_PDCABaseAttributeKey = {};
g_PDCABaseAttributeKey.sn = IPTable.IP_ATTRIBUTE_SERIALNUMBER;
g_PDCABaseAttributeKey.limitVersion = IPTable.IP_ATTRIBUTE_STATIONLIMITSVERSION;
g_PDCABaseAttributeKey.swName = IPTable.IP_ATTRIBUTE_STATIONSOFTWARENAME;
g_PDCABaseAttributeKey.swVersion = IPTable.IP_ATTRIBUTE_STATIONSOFTWAREVERSION;
g_PDCABaseAttributeKey.stationID = IPTable.IP_ATTRIBUTE_STATIONIDENTIFIER;
----------------------------------------------------------------------------------  


