------------------------------------------NetworkCB Module------------------------------
print("load and do NetworkCB script...");

local bStatus, ip = pcall(require, "KylinSkunk");
if bStatus and ip then
    print("require KylinSkunk success!");
else
    print("require KylinSkunk fail:", ip);
    return;
end

----------------------------------------------------------------------------------------
local bCbaStatus, cba = pcall(require, "cba");
if bCbaStatus and cba then
    print("require cba library success!");
else
    print("require cba library fail:", cba);
    return;
end

--------------------------------------Private Function-----------------------------------
local g_NetworkCBLogInfo = {} 
local function IPTrace(anInfo)
    print(anInfo);
    table.insert(g_NetworkCBLogInfo, anInfo);
end

----------------------------------------------------------------------------------------
local function isNull(anObject)
    return (anObject==nil) or (tostring(anObject)=="userdata: 0x0");
end

----------------------------------------------------------------------------------------
local function isSuccess(reply)
    if isNull(reply) then
        IPTrace("Error: reply is NULL");
        return false;
    end
    local bRt = ip.success(reply);
    if not bRt then
        local errorInfo = ip.reply_getError(reply);
        IPTrace("Error:" .. tostring(errorInfo));
    end
    ip.reply_destroy(reply);

    return (bRt==true);
end

----------------------------------------------------------------------------------------
local function amIOkay(UUTHandle, dutSn)
    if isNull(UUTHandle) then
        IPTrace("Error: UUTHandle is NULL");
        return false;
    end
    local reply = ip.amIOkay(UUTHandle, dutSn);
    local bRt = isSuccess(reply);
    if not bRt then
        IPTrace("Error: amIOkay fail");
    end

    return (bRt==true);
end

----------------------------------------------------------------------------------------
local function cancelUUTHandle(UUTHandle)
    if isNull(UUTHandle) then
        IPTrace("Error: UUTHandle is NULL");
        return false;
    end
    local reply = ip.UUTCancel(UUTHandle);
    local bRt = isSuccess(reply);
    if not bRt then
        IPTrace("Error: UUTCancel fail!");
    end

    return (bRt==true);
end

----------------------------------------------------------------------------------------
local function freeUUTHandle(UUTHandle)
    if not isNull(UUTHandle) then
        cancelUUTHandle(UUTHandle);
        ip.UID_destroy(UUTHandle);
    end
end

------------------------------------------Interface---------------------------------------
function checkNetworkCB(dutSn, tbDutCBInfo, stationIndex)
    g_NetworkCBLogInfo = {};   
    if (not dutSn) or (not tbDutCBInfo) or (not stationIndex) then
        local parameter = tostring(dutSn) .. " " .. tostring(tbDutCBInfo) .. " " .. tostring(stationIndex);
        IPTrace("parameter is invalid: " .. parameter);
        return false, table.concat(g_NetworkCBLogInfo, "\n");
    end

    ---------------------------------------
    local reply, UUTHandle = ip.UUTStart();
    local bRt = isSuccess(reply);
    if not bRt then
        IPTrace("UUTStart fail");
        freeUUTHandle(UUTHandle);
        return false, table.concat(g_NetworkCBLogInfo, "\n");
    end

    ---------------------------------------
    reply = ip.validateSerialNumber(UUTHandle, dutSn);
    bRt = isSuccess(reply);
    if not bRt then
        IPTrace("dutSn invalid:" .. dutSn);
        freeUUTHandle(UUTHandle);
        return false, table.concat(g_NetworkCBLogInfo, "\n");
    end
    freeUUTHandle(UUTHandle);

    ---------------------------------------
    local checkCount = cba.GetCountCBsToCheckSN(dutSn);
    if checkCount > 0 then
        local nRt,tbCBIndex,nLength,tbCBName = cba.ControlBitsToCheckSN(dutSn, checkCount);
        for key, value in pairs(tbCBIndex) do
            if tbDutCBInfo[value] and tbDutCBInfo[value].state ~= "Passed" then
                bRt = false
                local anIndex = string.format("%02x", value);
                IPTrace("not passed station: " .. tbCBName[key] .. " : " .. anIndex);
            end
        end
    end

    if not bRt then
        return false, table.concat(g_NetworkCBLogInfo, "\n");
    end

    ---------------------------------------
    local allowedFailCount = cba.StationFailCountAllowedSN(dutSn);
    local haveFailCount = tbDutCBInfo[tonumber(stationIndex)] and tbDutCBInfo[tonumber(stationIndex)].relativeFailCount;
    if not haveFailCount then
        IPTrace("can't get relative fail count!");
        return false, table.concat(g_NetworkCBLogInfo, "\n");
    end
    allowedFailCount = tonumber(allowedFailCount)
    haveFailCount = tonumber(haveFailCount)
    if allowedFailCount > 0  and haveFailCount >= allowedFailCount then
        bRt = false;
    end

    if not bRt then
        IPTrace("fail: more than allowed fail count");
        IPTrace("allowedFailCount:" .. tostring(allowedFailCount));
        IPTrace("haveFailCount:" ..  tostring(haveFailCount));
        return false, table.concat(g_NetworkCBLogInfo, "\n");
    end

    ---------------------------------------
    IPTrace("check network CB OK!");
    return true, table.concat(g_NetworkCBLogInfo, "\n");
end

----------------------------------------------------------------------------------------
function getClearNetworkCBIndex(dutSn, theResult)
    g_NetworkCBLogInfo = {}
    local tbClearIndex = nil
    if (not dutSn) or (theResult == nil) then
        local parameter = tostring(dutSn) .. " " .. tostring(theResult);
        IPTrace("parameter is invalid: " .. parameter);
        return false, table.concat(g_NetworkCBLogInfo, "\n"), tbClearIndex;
    end

    ---------------------------------------
    local reply, UUTHandle = ip.UUTStart();
    local bRt = isSuccess(reply);
    if not bRt then
        IPTrace("UUTStart fail");
        freeUUTHandle(UUTHandle);
        return false, table.concat(g_NetworkCBLogInfo, "\n"), tbClearIndex;
    end

    bRt = amIOkay(UUTHandle, dutSn);
    if not bRt then
        IPTrace("amIOkay query fail!");
        freeUUTHandle(UUTHandle);
        return false, table.concat(g_NetworkCBLogInfo, "\n"),tbClearIndex;
    end
    freeUUTHandle(UUTHandle)

    ---------------------------------------
    local CBSetStatus = cba.StationSetControlBitSN(dutSn)
    if CBSetStatus <= 0 then
        IPTrace("station control bit set to off");
        return true, table.concat(g_NetworkCBLogInfo, "\n"), tbClearIndex;
    end  

    ---------------------------------------
    if theResult then
        local clearCount = cba.GetCountCBsToClearOnPassSN(dutSn)
        if clearCount <= 0 then
            IPTrace("no station to clear on pass");
            return true, table.concat(g_NetworkCBLogInfo, "\n"), tbClearIndex;
        end

        local nRt,tbCBIndexOnPass,iLength = cba.ControlBitsToClearOnPassSN(dutSn, clearCount)
        if iLength <= 0 then
            IPTrace("error: get clear network CB index on pass:".. tostring(cba.cbGetErrMsg(iLength)));
            return false, table.concat(g_NetworkCBLogInfo, "\n"), tbClearIndex;
        end
        tbClearIndex = tbCBIndexOnPass
    else
        local clearCount = cba.GetCountCBsToClearOnFailSN(dutSn)
        if clearCount <= 0 then
            IPTrace("no station to clear on fail");
            return true, table.concat(g_NetworkCBLogInfo, "\n"), tbClearIndex;
        end 

        local nRt,tbCBIndexOnFail,iLength = cba.ControlBitsToClearOnFailSN(dutSn,clearCount)
        if iLength <= 0 then
            IPTrace("error:get clear network CB index on fail:".. tostring(cba.cbGetErrMsg(iLength)));
            return false,table.concat(g_NetworkCBLogInfo, "\n"), tbClearIndex;
        end
        tbClearIndex = tbCBIndexOnFail;
    end

    ---------------------------------------
    IPTrace("get clear network CB index OK!");
    return true, table.concat(g_NetworkCBLogInfo, "\n"), tbClearIndex;
end

----------------------------------------------------------------------------------------
function getStationHashCodeByCBA(passCode, rtRecvGetNonce)
  g_NetworkCBLogInfo = {}
  local iLength = -1
  local hashCode = nil
  local bRt = false
  if (not passCode) or (not rtRecvGetNonce) then
    local parameter = tostring(passCode) .. " " .. tostring(rtRecvGetNonce);
    IPTrace("parameter is invalid: " .. parameter);
    return bRt, hashCode, table.concat(g_NetworkCBLogInfo, "\n");
  end
  if string.len(tostring(rtRecvGetNonce)) < 30 then
    IPTrace("get nonce return error");
    return bRt, hashCode, table.concat(g_NetworkCBLogInfo, "\n");
  end

  ---------------------------------------
  local rtRecvNonce = string.sub(rtRecvGetNonce,11,30)
  hashCode,iLength = cba.CreateSHA1(passCode, rtRecvNonce)
  if iLength == 20 then
    IPTrace("STATUS_OK");
    bRt = true;
  end
  return bRt, hashCode, table.concat(g_NetworkCBLogInfo, "\n");
end
----------------------------------------------------------------------------------------





